# Integrated Restaurant Management System (MERN)
React + Tailwind + Recharts | Express + Socket.IO | MongoDB + Mongoose. Rule-based intelligence (no ML). Payments are **simulated**.

## Run locally
Prerequisites: Node 18+, MongoDB running locally (or an Atlas URI in `backend/.env`).
```
cd backend && npm install && npm run seed && npm start      # API on :5000
cd frontend && npm install && npm run dev                    # UI on http://localhost:5173
```
## Demo accounts (password: `password123`)
admin@rms.com | manager@rms.com (Downtown) | manager2@rms.com (Lakeside) | kitchen@rms.com | delivery@rms.com | customer@rms.com

QR ordering: open `http://localhost:5173/?table=T5` after login to order for that table.

## Workflow
Customer orders -> Received -> Confirmed -> Preparing (ingredients auto-deducted from recipes) -> Ready -> Served / Out for Delivery -> Completed (payment marked paid, loyalty points awarded). Socket.IO syncs customer, manager, kitchen and delivery screens.

## Intelligence (backend/services/intelligence.js)
- Menu optimization: sales x recipe cost -> margin; Star/Workhorse/Puzzle/Dog classification.
- Exceptions: stuck orders (Received/Confirmed 10, Preparing 20, Ready 10 min), kitchen bottleneck (5+ preparing), low stock, long preparation. Managers can resolve.
- Customer Experience Score = 0.30*Wait + 0.20*Accuracy + 0.30*Rating*20 + 0.20*Completion (weights in `CX_WEIGHTS`).
- Recommendations and Demand forecast: historical averages and rules.

## API (all under /api)
auth: POST /auth/register, /auth/login, GET /auth/me | menu: GET/POST/PUT/DELETE /menu | orders: POST/GET /orders, PATCH /orders/:id/status | kitchen: GET /kitchen/orders, PATCH /kitchen/orders/:id/status | inventory: GET/POST/PATCH /inventory, GET /inventory/alerts | deliveries: GET /deliveries, POST /deliveries/assign, PATCH /deliveries/:id/status | reservations: POST/GET/PATCH /reservations (overlap blocked, 409) | intelligence: GET /intelligence/{menu-optimization,exceptions,customer-experience,recommendations,demand-forecast} | analytics: GET /analytics/{overview,branches} | marketing: GET /marketing/segments | loyalty: GET /loyalty/:id | feedback: POST /feedback | branches: GET/POST /branches

## Status checklist
Implemented: auth + roles + branch scoping, menu CRUD API, stock-aware availability, cart/checkout, simulated payments, KDS, order tracking, inventory + auto-deduction + alerts, delivery accept/status, reservations API, 5 intelligence dashboards, analytics, multi-branch comparison, seed data.
Partial: loyalty (points earned/shown; redemption not built), marketing (segments API only), POS (use Orders page), QR (table via URL param; no QR image generator).
Pending: menu CRUD / reservation / waste / purchase-order / campaign UIs, separate Payments/Suppliers/Notifications/Waste collections, tests, live GPS.
Untested here: the app was syntax-checked but not run against a live MongoDB.

// Central, configurable thresholds & weights (documented in README)
module.exports = {
  TAX_RATE: 0.05,
  LOYALTY_EARN_PER: 10,          // 1 point per 10 currency units
  PREP_DELAY_MIN: 20,            // Preparing longer than this => delay alert
  STUCK_MIN: { Received: 10, Confirmed: 10, Preparing: 30, Ready: 15 },
  BOTTLENECK_ORDERS: 5,          // simultaneous Preparing orders per branch
  TARGET_WAIT_MIN: 25,
  CX_WEIGHTS: { waiting: 0.25, accuracy: 0.20, rating: 0.25, feedback: 0.15, completion: 0.15 },
  MARGIN_GOOD: 0.55
};

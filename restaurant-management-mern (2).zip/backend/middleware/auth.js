const jwt=require('jsonwebtoken');
exports.auth=(req,res,next)=>{try{req.user=jwt.verify((req.headers.authorization||'').replace('Bearer ',''),process.env.JWT_SECRET);next()}catch{res.status(401).json({message:'Not authenticated'})}};
exports.allow=(...r)=>(req,res,next)=>r.includes(req.user.role)?next():res.status(403).json({message:'Forbidden for role '+req.user.role});

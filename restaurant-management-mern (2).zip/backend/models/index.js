const m=require('mongoose'),S=m.Schema,O=S.Types.ObjectId;
const mk=(n,d,idx)=>{const s=new S(d,{timestamps:true});(idx||[]).forEach(i=>s.index(i));return m.model(n,s)};
exports.Branch=mk('Branch',{name:{type:String,required:true},address:String});
exports.User=mk('User',{name:{type:String,required:true},email:{type:String,required:true,unique:true,lowercase:true},password:{type:String,required:true,minlength:6},role:{type:String,enum:['admin','manager','customer','kitchen','delivery'],default:'customer'},branch:{type:O,ref:'Branch'},loyaltyPoints:{type:Number,default:0}});
exports.Ingredient=mk('Ingredient',{name:{type:String,required:true},unit:String,stock:{type:Number,min:0},minStock:Number,costPerUnit:Number,branch:{type:O,ref:'Branch'}},[{branch:1,name:1}]);
exports.MenuItem=mk('MenuItem',{name:{type:String,required:true},category:String,description:String,price:{type:Number,min:0,required:true},image:String,available:{type:Boolean,default:true},recipe:[{ingredient:String,qty:Number}]});
exports.Order=mk('Order',{number:Number,branch:{type:O,ref:'Branch'},customer:{type:O,ref:'User'},type:{type:String,enum:['dine-in','takeaway','delivery'],default:'dine-in'},table:String,address:String,
 items:[{name:String,price:Number,qty:{type:Number,min:1},notes:String}],subtotal:Number,tax:Number,discount:{type:Number,default:0},total:Number,
 status:{type:String,enum:['Received','Confirmed','Preparing','Ready','Out for Delivery','Served','Completed','Cancelled'],default:'Received'},
 paymentMethod:{type:String,enum:['Cash','UPI','Card','Online'],default:'Cash'},paymentStatus:{type:String,default:'Pending'},driver:{type:O,ref:'User'},stocked:Boolean,pointsAwarded:Boolean,
 stamps:{type:S.Types.Mixed,default:{}}},[{branch:1,status:1},{customer:1}]);
exports.Feedback=mk('Feedback',{order:{type:O,ref:'Order'},branch:{type:O,ref:'Branch'},customer:{type:O,ref:'User'},rating:{type:Number,min:1,max:5},accurate:{type:Boolean,default:true},comment:String});
exports.Exception=mk('Exception',{key:String,type:String,severity:String,branch:{type:O,ref:'Branch'},order:{type:O,ref:'Order'},description:String,action:String,resolved:{type:Boolean,default:false}},[{key:1,resolved:1}]);
exports.Reservation=mk('Reservation',{branch:{type:O,ref:'Branch'},customer:{type:O,ref:'User'},table:{type:String,required:true},start:{type:Date,required:true},end:{type:Date,required:true},guests:Number,status:{type:String,default:'Confirmed'}},[{branch:1,table:1,start:1}]);

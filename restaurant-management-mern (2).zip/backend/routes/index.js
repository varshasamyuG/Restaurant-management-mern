const r=require('express').Router(),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const M=require('../models'),I=require('../services/intelligence'),{auth,allow}=require('../middleware/auth');
const w=fn=>(q,s,n)=>Promise.resolve(fn(q,s,n)).catch(n);
const STAFF=['admin','manager','kitchen','delivery'],MGR=['admin','manager'];
const scope=q=>q.user.role==='admin'?(q.query.branch?{branch:q.query.branch}:{}):{branch:q.user.branch};
const tok=u=>jwt.sign({id:u._id,role:u.role,branch:u.branch},process.env.JWT_SECRET,{expiresIn:'1d'});
const pub=u=>({id:u._id,name:u.name,email:u.email,role:u.role,branch:u.branch,loyaltyPoints:u.loyaltyPoints});
const need=(o,...k)=>{for(const x of k)if(!o[x])throw Object.assign(new Error(`${x} is required`),{status:400})};

// Auth
r.post('/auth/register',w(async(q,s)=>{need(q.body,'name','email','password');const b=await M.Branch.findOne();
 const u=await M.User.create({name:q.body.name,email:q.body.email,password:await bcrypt.hash(q.body.password,10),role:'customer',branch:b?._id});s.status(201).json({token:tok(u),user:pub(u)})}));
r.post('/auth/login',w(async(q,s)=>{const u=await M.User.findOne({email:(q.body.email||'').toLowerCase()});
 if(!u||!await bcrypt.compare(q.body.password||'',u.password))return s.status(401).json({message:'Invalid email or password'});s.json({token:tok(u),user:pub(u)})}));
r.get('/auth/me',auth,w(async(q,s)=>s.json(pub(await M.User.findById(q.user.id)))));
r.get('/branches',w(async(q,s)=>s.json(await M.Branch.find())));
r.post('/branches',auth,allow('admin'),w(async(q,s)=>s.status(201).json(await M.Branch.create(q.body))));

// Menu (public read; stock-aware availability)
r.get('/menu',w(async(q,s)=>{const items=await M.MenuItem.find().lean(),stock={};
 if(q.query.branch)(await M.Ingredient.find({branch:q.query.branch})).forEach(i=>stock[i.name]=i.stock);
 s.json(items.map(m=>({...m,inStock:!q.query.branch||m.recipe.every(x=>(stock[x.ingredient]??0)>=x.qty)})))}));
r.post('/menu',auth,allow(...MGR),w(async(q,s)=>s.status(201).json(await M.MenuItem.create(q.body))));
r.put('/menu/:id',auth,allow(...MGR),w(async(q,s)=>s.json(await M.MenuItem.findByIdAndUpdate(q.params.id,q.body,{new:true,runValidators:true}))));
r.delete('/menu/:id',auth,allow(...MGR),w(async(q,s)=>{await M.MenuItem.findByIdAndDelete(q.params.id);s.json({ok:true})}));

// Orders
const emit=(q,o)=>q.app.get('io').emit('order:update',{id:o._id,status:o.status,branch:o.branch});
r.post('/orders',auth,w(async(q,s)=>{const{items,type,table,address,paymentMethod,discount=0,branch,notes}=q.body;
 if(!items?.length)throw Object.assign(new Error('Cart is empty'),{status:400});
 const menu=await M.MenuItem.find({_id:{$in:items.map(i=>i.menuItem)}}),br=branch||q.user.branch;
 const lines=items.map(i=>{const m=menu.find(x=>x.id===i.menuItem);if(!m||!m.available)throw Object.assign(new Error('Item unavailable'),{status:400});return{name:m.name,price:m.price,qty:Math.max(1,+i.qty||1),notes:i.notes}});
 const subtotal=lines.reduce((a,l)=>a+l.price*l.qty,0),tax=+(subtotal*0.05).toFixed(2),total=+(subtotal+tax-discount).toFixed(2);
 const demo=['UPI','Card','Online'].includes(paymentMethod);// payment is SIMULATED (demo mode)
 const o=await M.Order.create({number:1001+await M.Order.countDocuments(),branch:br,customer:q.user.role==='customer'?q.user.id:q.body.customer,type,table,address,items:lines,subtotal,tax,discount,total,
  paymentMethod,paymentStatus:demo?'Paid (demo)':'Pending',stamps:{Received:new Date()}});emit(q,o);s.status(201).json(o)}));
r.get('/orders',auth,w(async(q,s)=>{const f=q.user.role==='customer'?{customer:q.user.id}:scope(q);s.json(await M.Order.find(f).sort({createdAt:-1}).limit(200))}));
r.get('/orders/:id',auth,w(async(q,s)=>s.json(await M.Order.findById(q.params.id))));
const FLOW={Received:['Confirmed','Cancelled'],Confirmed:['Preparing','Cancelled'],Preparing:['Ready'],Ready:['Out for Delivery','Served'],'Out for Delivery':['Completed'],Served:['Completed']};
async function setStatus(q,s,id,status){const o=await M.Order.findById(id);if(!o)return s.status(404).json({message:'Order not found'});
 if(!(FLOW[o.status]||[]).includes(status))return s.status(400).json({message:`Cannot move ${o.status} -> ${status}`});
 if(status==='Preparing'&&!o.stocked){for(const it of o.items){const mi=await M.MenuItem.findOne({name:it.name});
   for(const rc of mi?.recipe||[])await M.Ingredient.updateOne({branch:o.branch,name:rc.ingredient},[{$set:{stock:{$max:[0,{$subtract:['$stock',rc.qty*it.qty]}]}}}])}o.stocked=true} // inventory auto-deduction
 if(status==='Completed'){if(o.paymentStatus==='Pending')o.paymentStatus='Paid';
   if(o.customer&&!o.pointsAwarded){await M.User.updateOne({_id:o.customer},{$inc:{loyaltyPoints:Math.floor(o.total/10)}});o.pointsAwarded=true}}
 o.status=status;o.stamps={...o.stamps,[status]:new Date()};o.markModified('stamps');await o.save();emit(q,o);s.json(o)}
r.patch('/orders/:id/status',auth,allow(...STAFF),w((q,s)=>setStatus(q,s,q.params.id,q.body.status)));
r.get('/kitchen/orders',auth,allow('admin','manager','kitchen'),w(async(q,s)=>s.json(await M.Order.find({...scope(q),status:{$in:['Received','Confirmed','Preparing','Ready']}}).sort({createdAt:1}))));
r.patch('/kitchen/orders/:id/status',auth,allow('admin','manager','kitchen'),w((q,s)=>setStatus(q,s,q.params.id,q.body.status)));

// Feedback
r.post('/feedback',auth,w(async(q,s)=>{const o=await M.Order.findById(q.body.order);s.status(201).json(await M.Feedback.create({order:o._id,branch:o.branch,customer:q.user.id,rating:q.body.rating,accurate:q.body.accurate!==false,comment:q.body.comment}))}));

// Inventory
r.get('/inventory',auth,allow(...MGR),w(async(q,s)=>s.json(await M.Ingredient.find(scope(q)).sort({name:1}))));
r.post('/inventory',auth,allow(...MGR),w(async(q,s)=>s.status(201).json(await M.Ingredient.create({...q.body,branch:q.body.branch||q.user.branch}))));
r.patch('/inventory/:id',auth,allow(...MGR),w(async(q,s)=>{const{add,...rest}=q.body;const u={...(add?{$inc:{stock:+add}}:{}),...(Object.keys(rest).length?{$set:rest}:{})};s.json(await M.Ingredient.findByIdAndUpdate(q.params.id,u,{new:true}))}));
r.get('/inventory/alerts',auth,allow(...MGR),w(async(q,s)=>s.json(await M.Ingredient.find({...scope(q),$expr:{$lte:['$stock','$minStock']}}))));

// Deliveries
r.get('/deliveries',auth,allow(...STAFF),w(async(q,s)=>s.json(await M.Order.find({...scope(q),type:'delivery',status:{$in:['Ready','Out for Delivery','Completed']}}).sort({createdAt:-1}).limit(50))));
r.post('/deliveries/assign',auth,allow(...MGR),w(async(q,s)=>s.json(await M.Order.findByIdAndUpdate(q.body.orderId,{driver:q.body.driverId},{new:true}))));
r.patch('/deliveries/:id/status',auth,allow('admin','manager','delivery'),w(async(q,s)=>{if(q.body.status==='Out for Delivery')await M.Order.updateOne({_id:q.params.id},{driver:q.user.id});return setStatus(q,s,q.params.id,q.body.status)}));

// Reservations (overlap prevention)
r.post('/reservations',auth,w(async(q,s)=>{need(q.body,'table','start');const start=new Date(q.body.start),end=new Date(+start+(q.body.minutes||90)*6e4),branch=q.body.branch||q.user.branch;
 if(await M.Reservation.findOne({branch,table:q.body.table,status:{$ne:'Cancelled'},start:{$lt:end},end:{$gt:start}}))return s.status(409).json({message:'Table already reserved for that time slot'});
 s.status(201).json(await M.Reservation.create({branch,customer:q.user.id,table:q.body.table,start,end,guests:q.body.guests}))}));
r.get('/reservations',auth,w(async(q,s)=>s.json(await M.Reservation.find(q.user.role==='customer'?{customer:q.user.id}:scope(q)).sort({start:1}))));
r.patch('/reservations/:id',auth,w(async(q,s)=>s.json(await M.Reservation.findByIdAndUpdate(q.params.id,{status:q.body.status},{new:true}))));

// Intelligence
const IA=[auth,allow(...MGR)];
r.get('/intelligence/menu-optimization',...IA,w(async(q,s)=>s.json(await I.menuOptimization(scope(q)))));
r.get('/intelligence/exceptions',...IA,w(async(q,s)=>s.json(await I.detectExceptions(scope(q)))));
r.patch('/intelligence/exceptions/:id/resolve',...IA,w(async(q,s)=>s.json(await M.Exception.findByIdAndUpdate(q.params.id,{resolved:true},{new:true}))));
r.get('/intelligence/customer-experience',...IA,w(async(q,s)=>s.json(await I.customerExperience(scope(q)))));
r.get('/intelligence/recommendations',...IA,w(async(q,s)=>s.json(await I.recommendations(scope(q)))));
r.get('/intelligence/demand-forecast',...IA,w(async(q,s)=>s.json(await I.demand(scope(q)))));

// Marketing: segmentation from order history (campaign UI/notifications: pending)
r.get('/marketing/segments',...IA,w(async(q,s)=>{const agg=await M.Order.aggregate([{$match:{status:'Completed',customer:{$ne:null}}},{$group:{_id:'$customer',orders:{$sum:1},spend:{$sum:'$total'}}}]);
 const seg=g=>agg.filter(g).length;s.json({VIP:seg(a=>a.orders>=8),Regular:seg(a=>a.orders>=3&&a.orders<8),New:seg(a=>a.orders<3)})}));
r.get('/loyalty/:id',auth,w(async(q,s)=>{const u=await M.User.findById(q.params.id);s.json({points:u.loyaltyPoints})}));

// Analytics
r.get('/analytics/overview',...IA,w(async(q,s)=>{const f=scope(q),t0=new Date();t0.setHours(0,0,0,0);
 const today=await M.Order.find({...f,createdAt:{$gte:t0},status:{$ne:'Cancelled'}}),all=await M.Order.find({...f,createdAt:{$gt:new Date(Date.now()-14*864e5)},status:{$ne:'Cancelled'}}),days={};
 all.forEach(o=>{const k=o.createdAt.toISOString().slice(0,10);days[k]=days[k]||{date:k,revenue:0,orders:0};days[k].revenue+=o.total;days[k].orders++});
 s.json({todayOrders:today.length,todayRevenue:+today.reduce((a,o)=>a+o.total,0).toFixed(2),active:await M.Order.countDocuments({...f,status:{$in:['Received','Confirmed','Preparing','Ready','Out for Delivery']}}),
  openExceptions:await M.Exception.countDocuments({...f,resolved:false}),lowStock:await M.Ingredient.countDocuments({...f,$expr:{$lte:['$stock','$minStock']}}),sales:Object.values(days).sort((a,b)=>a.date<b.date?-1:1)})}));
r.get('/analytics/branches',auth,allow('admin'),w(async(q,s)=>{const out=[];for(const b of await M.Branch.find()){const o=await M.Order.find({branch:b._id,status:{$ne:'Cancelled'}});out.push({branch:b.name,orders:o.length,revenue:+o.reduce((a,x)=>a+x.total,0).toFixed(0)})}s.json(out)}));
module.exports=r;

// Demonstration data (clearly synthetic). Run: npm run seed
require('dotenv').config();const mongoose=require('mongoose'),bcrypt=require('bcryptjs'),M=require('./models');
let seed=42;const rnd=()=>(seed=(seed*16807)%2147483647)/2147483647,pick=a=>a[Math.floor(rnd()*a.length)];
const ING=[['Chicken','kg',0.0],['Rice','kg'],['Paneer','kg'],['Tomato','kg'],['Onion','kg'],['Flour','kg'],['Cheese','kg'],['Butter','kg'],['Lamb','kg'],['Fish','kg'],['Potato','kg'],['Cream','l']];
const PRICE={Chicken:180,Rice:60,Paneer:300,Tomato:40,Onion:30,Flour:35,Cheese:400,Butter:500,Lamb:700,Fish:450,Potato:25,Cream:220};
const MENU=[['Butter Chicken','Mains',320,[['Chicken',.25],['Butter',.03],['Cream',.05],['Tomato',.1]]],['Chicken Biryani','Mains',280,[['Chicken',.2],['Rice',.2],['Onion',.05]]],
['Paneer Tikka','Starters',240,[['Paneer',.15],['Onion',.03]]],['Palak Paneer','Mains',260,[['Paneer',.15],['Cream',.03]]],['Margherita Pizza','Pizza',299,[['Flour',.2],['Cheese',.12],['Tomato',.1]]],
['Cheese Burst Pizza','Pizza',399,[['Flour',.25],['Cheese',.25],['Tomato',.1]]],['Lamb Rogan Josh','Mains',480,[['Lamb',.25],['Onion',.08],['Tomato',.1]]],['Fish Curry','Mains',380,[['Fish',.22],['Tomato',.1],['Onion',.05]]],
['French Fries','Starters',120,[['Potato',.2]]],['Veg Biryani','Mains',220,[['Rice',.2],['Potato',.1],['Onion',.05]]],['Chicken 65','Starters',260,[['Chicken',.2],['Flour',.03]]],['Garlic Naan','Breads',60,[['Flour',.1],['Butter',.01]]],
['Butter Naan','Breads',55,[['Flour',.1],['Butter',.02]]],['Steamed Rice','Sides',90,[['Rice',.2]]],['Tomato Soup','Starters',140,[['Tomato',.3],['Cream',.02]]],['Cream of Mushroom Soup','Starters',160,[['Cream',.1],['Butter',.02]]],
['Fish Fingers','Starters',290,[['Fish',.2],['Flour',.05]]],['Paneer Butter Masala','Mains',290,[['Paneer',.16],['Butter',.03],['Tomato',.1]]],['Cheese Sandwich','Snacks',150,[['Cheese',.05],['Flour',.1]]],['Truffle Lamb Platter','Mains',890,[['Lamb',.4],['Butter',.05],['Cream',.05]]]];
(async()=>{await mongoose.connect(process.env.MONGO_URI);await mongoose.connection.dropDatabase();
 const pw=await bcrypt.hash('password123',10),[b1,b2]=await M.Branch.create([{name:'Downtown Branch',address:'12 MG Road, Mumbai'},{name:'Lakeside Branch',address:'45 Powai Lake Rd, Mumbai'}]);
 const U=(name,email,role,branch)=>({name,email,role,branch,password:pw});
 await M.User.create([U('Admin','admin@rms.com','admin'),U('Downtown Manager','manager@rms.com','manager',b1._id),U('Downtown Chef','kitchen@rms.com','kitchen',b1._id),U('Downtown Rider','delivery@rms.com','delivery',b1._id),U('Lakeside Manager','manager2@rms.com','manager',b2._id)]);
 const custs=await M.User.create(['Asha','Ravi','Meera','Karan','Divya','Imran','Sneha','Arjun'].map((n,i)=>U(n,`customer${i||''}@rms.com`.replace('customer0','customer'),'customer',b1._id)));
 const ings=[];for(const b of [b1,b2])for(const [n,u] of ING){const min=n==='Rice'?15:5;ings.push({name:n,unit:u,costPerUnit:PRICE[n],minStock:min,stock:Math.round(40+rnd()*60),branch:b._id})}
 ings.find(i=>i.name==='Paneer'&&String(i.branch)===String(b1._id)).stock=3;ings.find(i=>i.name==='Cheese'&&String(i.branch)===String(b1._id)).stock=4;ings.find(i=>i.name==='Lamb'&&String(i.branch)===String(b2._id)).stock=0;await M.Ingredient.create(ings);
 const menu=await M.MenuItem.create(MENU.map(([name,category,price,rc],i)=>({name,category,price,description:`${name} - freshly prepared (demo data)`,recipe:rc.map(([ingredient,qty])=>({ingredient,qty}))})));
 const weight=menu.map((m,i)=>i<6?5:i<14?3:i<18?1.5:.3);const tw=weight.reduce((a,b)=>a+b),pickItem=()=>{let x=rnd()*tw;for(let i=0;i<menu.length;i++){x-=weight[i];if(x<=0)return menu[i]}return menu[0]};
 const orders=[];let n=1001;const DAY=864e5;
 for(let d=14;d>=0;d--)for(const [b,slow] of [[b1,1],[b2,1.8]]){const cnt=(d===0?8:14+Math.floor(rnd()*10));
  for(let k=0;k<cnt;k++){const hr=pick([12,13,13,13,14,19,20,20,20,21,18]),t=new Date(Date.now()-d*DAY);t.setHours(hr,Math.floor(rnd()*60));if(d===0&&t>new Date())t.setTime(Date.now()-rnd()*5*36e5);
   const items=Array.from({length:1+Math.floor(rnd()*3)},()=>{const m=pickItem();return{name:m.name,price:m.price,qty:1+Math.floor(rnd()*2)}}),sub=items.reduce((a,i)=>a+i.price*i.qty,0),tax=+(sub*.05).toFixed(2);
   const type=pick(['dine-in','dine-in','takeaway','delivery']),prep=(8+rnd()*12)*slow,o={number:n++,branch:b._id,customer:pick(custs)._id,type,table:type==='dine-in'?'T'+(1+Math.floor(rnd()*8)):undefined,address:type==='delivery'?'Flat 4B, Hill View Apts':undefined,
    items,subtotal:sub,tax,total:+(sub+tax).toFixed(2),paymentMethod:pick(['Cash','UPI','Card']),createdAt:t,updatedAt:t};
   if(d>0||k<4){const P=new Date(+t+2*6e4),R=new Date(+P+prep*6e4);o.status='Completed';o.paymentStatus='Paid';o.pointsAwarded=true;o.stocked=true;o.stamps={Received:t,Confirmed:new Date(+t+6e4),Preparing:P,Ready:R,Completed:new Date(+R+10*6e4)}}
   else{const st=['Received','Preparing','Preparing','Ready'][k-4]||'Preparing',ago=st==='Preparing'?(30+k*5)*6e4:(4*6e4);o.status=st;o.stamps={Received:new Date(Date.now()-ago-3*6e4),Confirmed:new Date(Date.now()-ago-2*6e4),[st]:new Date(Date.now()-ago)};o.createdAt=new Date(Date.now()-ago-3*6e4);o.stocked=st!=='Received'}
   orders.push(o)}}
 const saved=await M.Order.insertMany(orders,{timestamps:false});
 await M.Feedback.insertMany(saved.filter(o=>o.status==='Completed'&&rnd()<.5).map(o=>{const slowB=String(o.branch)===String(b2._id);return{order:o._id,branch:o.branch,customer:o.customer,rating:Math.max(1,Math.min(5,Math.round((slowB?3.3:4.4)+(rnd()-.5)*2))),accurate:rnd()>(slowB?.15:.06),comment:'Demo feedback',createdAt:o.createdAt}}));
 await M.Reservation.create({branch:b1._id,customer:custs[0]._id,table:'T3',start:new Date(Date.now()+864e5),end:new Date(Date.now()+864e5+54e5),guests:4});
 console.log('Seeded. Orders:',saved.length);process.exit(0)})().catch(e=>{console.error(e);process.exit(1)});

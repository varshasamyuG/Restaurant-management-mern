require('dotenv').config();
const express=require('express'),cors=require('cors'),mongoose=require('mongoose'),http=require('http');
const {Server}=require('socket.io');
const app=express();app.use(cors(),express.json());
const server=http.createServer(app);
app.set('io',new Server(server,{cors:{origin:'*'}}));
app.use('/api',require('./routes'));
app.use((e,req,res,next)=>res.status(e.status||(e.name==='ValidationError'?400:500)).json({message:e.message}));
mongoose.connect(process.env.MONGO_URI).then(()=>server.listen(process.env.PORT||5000,()=>console.log('API running on :'+(process.env.PORT||5000)))).catch(e=>{console.error('MongoDB connection failed:',e.message);process.exit(1)});

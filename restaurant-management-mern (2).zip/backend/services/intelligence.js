// Rule-based intelligence engine (no ML). Every output is computed from stored order/inventory/feedback data.
const {Order,Ingredient,MenuItem,Exception,Feedback,Branch}=require('../models');
const THRESH={Received:10,Confirmed:10,Preparing:20,Ready:10}; // minutes before an order is "stuck"
const CX_WEIGHTS={wait:0.3,accuracy:0.2,rating:0.3,completion:0.2}, WAIT_TARGET=20; // configurable
const mins=d=>(Date.now()-new Date(d))/6e4, r1=n=>Math.round(n*10)/10;

exports.menuOptimization=async f=>{
 const orders=await Order.find({...f,status:{$ne:'Cancelled'}}), ings=await Ingredient.find(f), items=await MenuItem.find();
 const cost={};ings.forEach(i=>{(cost[i.name]=cost[i.name]||[]).push(i.costPerUnit)});
 const uc=n=>cost[n]?cost[n].reduce((a,b)=>a+b,0)/cost[n].length:0;
 const agg={};orders.forEach(o=>o.items.forEach(i=>{const a=agg[i.name]||(agg[i.name]={qty:0,revenue:0});a.qty+=i.qty;a.revenue+=i.qty*i.price}));
 const rows=items.map(mi=>{const a=agg[mi.name]||{qty:0,revenue:0},c=mi.recipe.reduce((s,r)=>s+uc(r.ingredient)*r.qty,0);
  return{name:mi.name,category:mi.category,price:mi.price,unitCost:r1(c),qty:a.qty,revenue:a.revenue,profit:r1(a.revenue-c*a.qty),margin:mi.price?r1((mi.price-c)/mi.price*100):0}});
 const med=rows.map(r=>r.qty).sort((a,b)=>a-b)[Math.floor(rows.length/2)]||0;
 const adv={Star:'High sales and healthy margin: feature prominently.',Workhorse:'High sales but low margin: review price or ingredient cost.',Puzzle:'Good margin but low sales: improve placement or promote.',Dog:'Low sales and low margin: review price or menu placement.'};
 rows.forEach(r=>{const s=r.qty>=med,m=r.margin>=65;r.class=s&&m?'Star':s?'Workhorse':m?'Puzzle':'Dog';r.advice=adv[r.class]});
 return rows.sort((a,b)=>b.qty-a.qty)};

exports.detectExceptions=async f=>{
 const found=[],act=await Order.find({...f,status:{$in:Object.keys(THRESH)}});
 act.forEach(o=>{const t=THRESH[o.status],m=mins(o.stamps[o.status]||o.createdAt);
  if(m>t)found.push({key:`stuck-${o._id}-${o.status}`,type:o.status==='Preparing'?'Order Delay':'Stuck Order',severity:m>2*t?'High':'Medium',branch:o.branch,order:o._id,
   description:`Order #${o.number} has been "${o.status}" for ${Math.round(m)} min (threshold ${t} min).`,action:o.status==='Preparing'?'Check with kitchen lead; prioritise or reassign.':'Advance or contact the customer.'})});
 const byB={};act.filter(o=>o.status==='Preparing').forEach(o=>(byB[o.branch]=byB[o.branch]||[]).push(o));
 Object.entries(byB).forEach(([b,l])=>{if(l.length>=5)found.push({key:`bottleneck-${b}-${new Date().toISOString().slice(0,13)}`,type:'Kitchen Bottleneck',severity:'High',branch:b,description:`${l.length} orders are in Preparing at the same time.`,action:'Add kitchen staff or pause new online orders briefly.'})});
 const low=await Ingredient.find({...f,$expr:{$lte:['$stock','$minStock']}});
 low.forEach(i=>found.push({key:`low-${i._id}`,type:'Low Inventory',severity:i.stock===0?'High':'Medium',branch:i.branch,description:`${i.name} stock is ${i.stock} ${i.unit} (minimum ${i.minStock}).`,action:`Raise a purchase order for ${i.name}.`}));
 const prepped=await Order.find({...f,'stamps.Preparing':{$exists:true},'stamps.Ready':{$exists:true},createdAt:{$gt:new Date(Date.now()-864e5)}});
 prepped.forEach(o=>{const d=(new Date(o.stamps.Ready)-new Date(o.stamps.Preparing))/6e4;if(d>THRESH.Preparing*1.5)found.push({key:`long-${o._id}`,type:'Long Preparation',severity:'Low',branch:o.branch,order:o._id,description:`Order #${o.number} took ${Math.round(d)} min to prepare.`,action:'Review recipe complexity and station workload.'})});
 for(const e of found)if(!await Exception.findOne({key:e.key}))await Exception.create(e);
 const keys=found.map(e=>e.key); // auto-clear stale open alerts whose condition no longer holds (stuck/low types only)
 await Exception.updateMany({...f,resolved:false,type:{$in:['Order Delay','Stuck Order','Low Inventory','Kitchen Bottleneck']},key:{$nin:keys}},{resolved:true});
 return Exception.find(f).sort({resolved:1,createdAt:-1}).limit(100)};

const cxFor=async f=>{
 const done=await Order.find({...f,'stamps.Ready':{$exists:true}}),waits=done.map(o=>(new Date(o.stamps.Ready)-new Date(o.createdAt))/6e4);
 const avgWait=waits.length?waits.reduce((a,b)=>a+b,0)/waits.length:0, wait=Math.max(0,Math.min(100,100-Math.max(0,avgWait-WAIT_TARGET)*4));
 const fb=await Feedback.find(f), avgRating=fb.length?fb.reduce((s,x)=>s+x.rating,0)/fb.length:0, accuracy=fb.length?fb.filter(x=>x.accurate).length/fb.length*100:0;
 const comp=await Order.countDocuments({...f,status:'Completed'}),canc=await Order.countDocuments({...f,status:'Cancelled'}),completion=comp+canc?comp/(comp+canc)*100:0;
 const W=CX_WEIGHTS,score=wait*W.wait+accuracy*W.accuracy+avgRating*20*W.rating+completion*W.completion;
 const tr={};fb.forEach(x=>{const k=x.createdAt.toISOString().slice(0,10);(tr[k]=tr[k]||[]).push(x.rating)});
 return{score:r1(score),avgWaitMin:r1(avgWait),waitScore:r1(wait),accuracy:r1(accuracy),avgRating:r1(avgRating),completion:r1(completion),feedbackCount:fb.length,
  trend:Object.entries(tr).sort().slice(-14).map(([d,a])=>({date:d,rating:r1(a.reduce((x,y)=>x+y,0)/a.length)}))}};
exports.customerExperience=async f=>{
 const branches=await Branch.find(f._id?{_id:f._id}:f.branch?{_id:f.branch}:{}),per=[];
 for(const b of branches)per.push({branch:b.name,...await cxFor({branch:b._id})});
 return{overall:await cxFor(f),perBranch:per,formula:'Score = 0.30*Wait + 0.20*Accuracy + 0.30*(Rating*20) + 0.20*Completion; Wait = 100 - 4*(avg minutes over '+WAIT_TARGET+'-minute target)',weights:CX_WEIGHTS}};

exports.demand=async f=>{
 const since=new Date(Date.now()-14*864e5),orders=await Order.find({...f,createdAt:{$gt:since},status:{$ne:'Cancelled'}}),ings=await Ingredient.find(f),menu=await MenuItem.find();
 const day={},hour=Array(24).fill(0),dow=Array(7).fill(0),dowDays=Array.from({length:7},()=>new Set());
 orders.forEach(o=>{const d=o.createdAt,k=d.toISOString().slice(0,10);day[k]=(day[k]||0)+1;hour[d.getHours()]++;dow[d.getDay()]++;dowDays[d.getDay()].add(k)});
 const nDays=Math.max(1,Object.keys(day).length),avgHour=hour.map((c,h)=>({hour:h,orders:r1(c/nDays)}));
 const forecast=[1,2,3,4,5,6,7].map(i=>{const d=new Date(Date.now()+i*864e5),w=d.getDay();return{date:d.toISOString().slice(0,10),expectedOrders:dowDays[w].size?r1(dow[w]/dowDays[w].size):r1(orders.length/nDays)}});
 const use={},rec={};menu.forEach(m=>rec[m.name]=m.recipe);
 orders.forEach(o=>o.items.forEach(i=>(rec[i.name]||[]).forEach(r=>use[r.ingredient]=(use[r.ingredient]||0)+r.qty*i.qty)));
 const replenish=ings.map(i=>{const daily=(use[i.name]||0)/nDays/Math.max(1,ings.filter(x=>x.name===i.name).length),need=daily*3;return{ingredient:i.name,branch:i.branch,stock:i.stock,unit:i.unit,avgDailyUse:r1(daily),suggestedOrder:Math.max(0,Math.ceil(need*2-i.stock))}}).filter(x=>x.suggestedOrder>0);
 return{daily:Object.entries(day).sort().map(([date,orders])=>({date,orders})),hourly:avgHour,forecast,replenish,method:'Historical averages over the last 14 days (day-of-week mean); no machine learning.'}};

exports.recommendations=async f=>{
 const out=[],orders=await Order.find({...f,createdAt:{$gt:new Date(Date.now()-14*864e5)}}),d=await exports.demand(f),menu=await exports.menuOptimization(f);
 const top=[...d.hourly].sort((a,b)=>b.orders-a.orders).slice(0,2);
 if(top[0]&&top[0].orders>0)out.push({title:'Increase kitchen staffing at peak hours',reason:'Recurring demand peaks detected in 14-day order history.',data:top.map(t=>`${t.hour}:00 avg ${t.orders} orders/day`).join('; '),action:`Schedule an extra cook around ${top[0].hour}:00-${top[0].hour+1}:00.`,priority:'High'});
 const low=await Ingredient.find({...f,$expr:{$lte:['$stock','$minStock']}});
 low.forEach(i=>out.push({title:`Replenish ${i.name}`,reason:'Stock is at or below the minimum threshold.',data:`${i.stock}/${i.minStock} ${i.unit}`,action:`Create a purchase order for ${i.name}; consider marking dependent dishes unavailable.`,priority:i.stock===0?'High':'Medium'}));
 const now=Date.now(),cnt={a:{},b:{}};orders.forEach(o=>{const k=now-o.createdAt<7*864e5?'a':'b';o.items.forEach(i=>cnt[k][i.name]=(cnt[k][i.name]||0)+i.qty)});
 Object.keys(cnt.a).forEach(n=>{const a=cnt.a[n],b=cnt.b[n]||0;if(a>=10&&a>b*1.3)out.push({title:`Trending: ${n}`,reason:'Sales rose over 30% versus the prior week.',data:`${a} this week vs ${b} previous`,action:'Highlight on the menu and ensure ingredient stock.',priority:'Medium'})});
 const delayed=await Order.countDocuments({...f,status:'Preparing','stamps.Preparing':{$lt:new Date(now-THRESH.Preparing*6e4)}});
 if(delayed)out.push({title:'Review preparation workflow',reason:'Orders are exceeding the preparation threshold.',data:`${delayed} order(s) over ${THRESH.Preparing} min`,action:'Inspect kitchen station load and ticket priority.',priority:'High'});
 menu.filter(m=>m.class==='Dog').slice(0,3).forEach(m=>out.push({title:`Review menu item: ${m.name}`,reason:m.advice,data:`${m.qty} sold, ${m.margin}% margin`,action:'Adjust price, reposition, or remove.',priority:'Low'}));
 return out.map(o=>({...o,status:'Open',engine:'rule-based'}))};

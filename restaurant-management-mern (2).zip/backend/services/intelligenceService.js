const mongoose = require('mongoose');
const M = require('../models');
const S = require('../config/settings');
const oid = id => (id ? new mongoose.Types.ObjectId(String(id)) : null);
const bf = branch => (branch ? { branch: oid(branch) } : {});
const since = d => new Date(Date.now() - d * 864e5);
const mins = (a, b) => (new Date(b) - new Date(a)) / 6e4;
const avg = a => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
const clamp = v => Math.max(0, Math.min(100, v));
const histAt = (o, st) => o.statusHistory.find(h => h.status === st)?.at;

// ---------- FEATURE 1: Smart menu optimization ----------
async function recipeCosts() {
  const [recipes, ings] = await Promise.all([M.Recipe.find(), M.Ingredient.find()]);
  const price = Object.fromEntries(ings.map(i => [String(i._id), i.costPerUnit]));
  return Object.fromEntries(recipes.map(r => [String(r.menuItem), r.items.reduce((s, x) => s + (price[String(x.ingredient)] || 0) * x.qty, 0)]));
}
async function menuOptimization(branch, days = 30) {
  const [orders, items, costs] = await Promise.all([
    M.Order.find({ ...bf(branch), status: { $ne: 'Cancelled' }, createdAt: { $gte: since(days) } }),
    M.MenuItem.find(), recipeCosts()
  ]);
  const half = since(days / 2), sales = {};
  for (const o of orders) for (const l of o.items) {
    const s = (sales[l.menuItem] ||= { qty: 0, revenue: 0, recent: 0, earlier: 0 });
    s.qty += l.qty; s.revenue += l.qty * l.price;
    o.createdAt >= half ? (s.recent += l.qty) : (s.earlier += l.qty);
  }
  const rows = items.map(i => {
    const s = sales[i._id] || { qty: 0, revenue: 0, recent: 0, earlier: 0 };
    const cost = costs[String(i._id)] ?? 0, margin = i.price ? (i.price - cost) / i.price : 0;
    return { id: i._id, name: i.name, price: i.price, qty: s.qty, revenue: s.revenue, unitCost: +cost.toFixed(2), margin: +margin.toFixed(3), profit: +(s.qty * (i.price - cost)).toFixed(2),
      trend: s.earlier ? +((s.recent - s.earlier) / s.earlier * 100).toFixed(0) : (s.recent ? 100 : 0) };
  });
  const sorted = rows.map(r => r.qty).sort((a, b) => a - b), median = sorted[Math.floor(sorted.length / 2)] || 0;
  rows.forEach(r => {
    const hi = r.qty > median, good = r.margin >= S.MARGIN_GOOD;
    r.class = hi && good ? 'Star' : hi ? 'Workhorse' : good ? 'Hidden gem' : 'Underperformer';
    r.recommendation = { Star: 'Keep prominent on the menu; protect quality and stock.',
      Workhorse: `Popular but margin is ${(r.margin * 100).toFixed(0)}%. Review price or recipe cost.`,
      'Hidden gem': 'Good margin, low sales. Promote or improve menu placement.',
      Underperformer: 'Low sales and low margin. Review price, placement or remove.' }[r.class];
  });
  return { medianQty: median, windowDays: days, items: rows.sort((a, b) => b.revenue - a.revenue) };
}

// ---------- FEATURE 2: Exception detection (rule-based, one function per rule so ML can replace any) ----------
async function upsertException(e) {
  const found = await M.Exception.findOne({ key: e.key, resolved: false });
  if (found) { Object.assign(found, { description: e.description, severity: e.severity }); return found.save(); }
  return M.Exception.create(e);
}
const rules = {
  async orderDelay(b) {
    const out = [];
    for (const o of await M.Order.find({ ...bf(b), status: 'Preparing' })) {
      const m = mins(histAt(o, 'Preparing'), Date.now());
      if (m > S.PREP_DELAY_MIN) out.push({ key: `delay:${o._id}`, type: 'Order delay', branch: o.branch, order: o._id, severity: m > S.PREP_DELAY_MIN * 2 ? 'critical' : 'high',
        description: `${o.number} in Preparing for ${Math.round(m)} min (threshold ${S.PREP_DELAY_MIN}).`, action: 'Check the kitchen station; notify the customer; prioritise this ticket.' });
    }
    return out;
  },
  async stuck(b) {
    const out = [];
    for (const [st, lim] of Object.entries(S.STUCK_MIN)) {
      if (st === 'Preparing') continue;
      for (const o of await M.Order.find({ ...bf(b), status: st })) {
        const m = mins(histAt(o, st), Date.now());
        if (m > lim) out.push({ key: `stuck:${o._id}:${st}`, type: 'Stuck order', branch: o.branch, order: o._id, severity: 'medium',
          description: `${o.number} has been "${st}" for ${Math.round(m)} min (limit ${lim}).`, action: st === 'Ready' ? 'Dispatch or serve the order.' : 'Confirm and start preparation.' });
      }
    }
    return out;
  },
  async bottleneck(b) {
    const g = await M.Order.aggregate([{ $match: { ...bf(b), status: 'Preparing' } }, { $group: { _id: '$branch', n: { $sum: 1 } } }]);
    return g.filter(x => x.n >= S.BOTTLENECK_ORDERS).map(x => ({ key: `bottleneck:${x._id}`, type: 'Kitchen bottleneck', branch: x._id, severity: 'high',
      description: `${x.n} orders are in Preparing at the same time (limit ${S.BOTTLENECK_ORDERS}).`, action: 'Add kitchen hands, pause online orders or stagger tickets.' }));
  },
  async longPrep(b) {
    const done = await M.Order.find({ ...bf(b), status: 'Completed', createdAt: { $gte: since(2) } }).populate('items.menuItem', 'prepMinutes');
    return done.filter(o => {
      const p = histAt(o, 'Preparing'), r = histAt(o, 'Ready'); if (!p || !r) return false;
      const exp = Math.max(...o.items.map(i => i.menuItem?.prepMinutes || 12));
      return mins(p, r) > exp * 2;
    }).map(o => ({ key: `longprep:${o._id}`, type: 'Long preparation', branch: o.branch, order: o._id, severity: 'low',
      description: `${o.number} took ${Math.round(mins(histAt(o, 'Preparing'), histAt(o, 'Ready')))} min, over twice its expected time.`, action: 'Review the recipe workflow for these items.' }));
  },
  async lowStock(b) {
    const inv = await M.Inventory.find(bf(b)).populate('ingredient');
    return inv.filter(i => i.quantity <= i.minThreshold).map(i => ({ key: `low:${i.branch}:${i.ingredient._id}`, type: 'Low inventory', branch: i.branch, ingredient: i.ingredient._id,
      severity: i.quantity <= i.minThreshold * 0.5 ? 'critical' : 'high',
      description: `${i.ingredient.name}: ${i.quantity.toFixed(1)} ${i.ingredient.unit} left (minimum ${i.minThreshold}).`, action: 'Raise a purchase order.' }));
  },
  async discrepancy(b) {
    // Ledger check: sum of stock transactions must not exceed what has ever been stocked; negative stock is impossible
    const inv = await M.Inventory.find(bf(b)).populate('ingredient');
    return inv.filter(i => i.quantity < 0).map(i => ({ key: `disc:${i.branch}:${i.ingredient._id}`, type: 'Inventory discrepancy', branch: i.branch, ingredient: i.ingredient._id, severity: 'high',
      description: `${i.ingredient.name} shows negative stock (${i.quantity.toFixed(1)}). Usage exceeds recorded stock-in.`, action: 'Run a physical stock count and post an adjustment.' }));
  }
};
async function detectExceptions(branch) {
  let n = 0;
  for (const r of Object.values(rules)) for (const e of await r(branch)) { await upsertException(e); n++; }
  // auto-close alerts whose condition is gone
  const open = await M.Exception.find({ ...bf(branch), resolved: false, type: { $in: ['Order delay', 'Stuck order'] } }).populate('order');
  for (const e of open) if (e.order && ['Ready', 'Served', 'Completed', 'Cancelled', 'Out for Delivery'].includes(e.order.status) && e.type === 'Order delay') { e.resolved = true; e.resolvedAt = new Date(); await e.save(); }
  return n;
}

// ---------- FEATURE 3: Customer Experience Score ----------
async function cxForBranch(branch, days = 30) {
  const w = S.CX_WEIGHTS, f = { branch, createdAt: { $gte: since(days) } };
  const [orders, fb] = await Promise.all([M.Order.find(f), M.Feedback.find(f)]);
  const completed = orders.filter(o => o.status === 'Completed'), cancelled = orders.filter(o => o.status === 'Cancelled');
  const waits = completed.map(o => mins(o.createdAt, histAt(o, 'Completed') || o.updatedAt)).filter(x => x >= 0);
  const avgWait = avg(waits);
  const waiting = waits.length ? clamp(100 - Math.max(0, avgWait - S.TARGET_WAIT_MIN) / S.TARGET_WAIT_MIN * 100) : 0;
  const accuracy = fb.length ? fb.filter(x => x.orderAccurate).length / fb.length * 100 : 0;
  const avgRating = avg(fb.map(x => x.rating)), rating = avgRating / 5 * 100;
  const positive = fb.length ? fb.filter(x => x.rating >= 4).length / fb.length * 100 : 0;
  const completion = completed.length + cancelled.length ? completed.length / (completed.length + cancelled.length) * 100 : 0;
  const score = waiting * w.waiting + accuracy * w.accuracy + rating * w.rating + positive * w.feedback + completion * w.completion;
  const trend = {};
  fb.forEach(x => { const d = x.createdAt.toISOString().slice(0, 10); (trend[d] ||= []).push(x.rating); });
  return { branch, score: +score.toFixed(1), avgWaitMin: +avgWait.toFixed(1), waitingScore: +waiting.toFixed(1), accuracy: +accuracy.toFixed(1), avgRating: +avgRating.toFixed(2),
    positiveFeedbackPct: +positive.toFixed(1), completionPct: +completion.toFixed(1), samples: { orders: orders.length, feedback: fb.length },
    feedbackTrend: Object.entries(trend).sort().map(([date, r]) => ({ date, rating: +avg(r).toFixed(2) })) };
}
async function customerExperience(branch) {
  const branches = branch ? await M.Branch.find({ _id: branch }) : await M.Branch.find();
  const rows = [];
  for (const b of branches) rows.push({ ...(await cxForBranch(b._id)), branchName: b.name });
  return { weights: S.CX_WEIGHTS, formula: 'score = Σ weight × component (waiting, accuracy, rating, positive feedback, completion), each component on 0–100', branches: rows,
    overall: +avg(rows.map(r => r.score)).toFixed(1) };
}

// ---------- FEATURE 4 + D: Forecast and recommendations ----------
async function demandForecast(branch) {
  const orders = await M.Order.find({ ...bf(branch), status: { $ne: 'Cancelled' }, createdAt: { $gte: since(28) } });
  const byDow = Array.from({ length: 7 }, () => ({ total: 0, days: new Set() })), hours = Array(24).fill(0), daily = {}, itemQty = {};
  for (const o of orders) {
    const d = o.createdAt, k = d.toISOString().slice(0, 10);
    byDow[d.getDay()].total++; byDow[d.getDay()].days.add(k); hours[d.getHours()]++; daily[k] = (daily[k] || 0) + 1;
    o.items.forEach(l => { itemQty[l.menuItem] = (itemQty[l.menuItem] || 0) + l.qty; });
  }
  const forecast = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() + (i + 1) * 864e5), s = byDow[d.getDay()];
    return { date: d.toISOString().slice(0, 10), day: d.toLocaleDateString('en', { weekday: 'short' }), expectedOrders: s.days.size ? Math.round(s.total / s.days.size) : 0 };
  });
  const totalDays = Math.max(1, Object.keys(daily).length), weekExpected = forecast.reduce((s, f) => s + f.expectedOrders, 0);
  const totalOrders = orders.length || 1;
  // Ingredient demand: expected weekly orders × each item's share of units × recipe qty
  const recipes = await M.Recipe.find().populate('items.ingredient', 'name unit');
  const unitsTotal = Object.values(itemQty).reduce((a, b) => a + b, 0) || 1, need = {};
  for (const r of recipes) {
    const units = (itemQty[r.menuItem] || 0) / unitsTotal * (weekExpected * (unitsTotal / totalOrders));
    r.items.forEach(ri => { const k = ri.ingredient.name; (need[k] ||= { ingredient: k, unit: ri.ingredient.unit, weeklyNeed: 0 }).weeklyNeed += ri.qty * units; });
  }
  const inv = await M.Inventory.find(bf(branch)).populate('ingredient', 'name');
  const have = {}; inv.forEach(i => { have[i.ingredient.name] = (have[i.ingredient.name] || 0) + i.quantity; });
  const ingredientDemand = Object.values(need).map(n => ({ ...n, weeklyNeed: +n.weeklyNeed.toFixed(1), inStock: +(have[n.ingredient] || 0).toFixed(1),
    suggestedReplenish: +Math.max(0, n.weeklyNeed - (have[n.ingredient] || 0)).toFixed(1) })).sort((a, b) => b.suggestedReplenish - a.suggestedReplenish);
  return { method: 'Weekday historical average over the last 28 days (no machine learning)', dailyTrend: Object.entries(daily).sort().map(([date, orders]) => ({ date, orders })),
    peakHours: hours.map((orders, hour) => ({ hour: `${hour}:00`, orders })), forecast, ingredientDemand: ingredientDemand.slice(0, 12), avgDailyOrders: +(orders.length / totalDays).toFixed(1) };
}

async function upsertRec(r) {
  const f = await M.Recommendation.findOne({ key: r.key, status: 'Open' });
  if (f) { Object.assign(f, r); return f.save(); }
  if (await M.Recommendation.findOne({ key: r.key, status: { $in: ['Dismissed', 'Done'] }, updatedAt: { $gte: since(1) } })) return;
  return M.Recommendation.create(r);
}
async function generateRecommendations(branch) {
  const branches = branch ? await M.Branch.find({ _id: branch }) : await M.Branch.find();
  for (const b of branches) {
    const id = b._id, [fc, menu, low] = await Promise.all([demandForecast(id), menuOptimization(id, 14), M.Inventory.find({ branch: id }).populate('ingredient')]);
    const peak = [...fc.peakHours].sort((a, b) => b.orders - a.orders).slice(0, 2);
    if (peak[0]?.orders) await upsertRec({ key: `staff:${id}`, branch: id, title: `Add kitchen staff around ${peak.map(p => p.hour).join(' and ')}`, priority: 'high',
      reason: 'Recurring peak-hour demand in the last 28 days.', data: { peakHours: peak, avgDailyOrders: fc.avgDailyOrders }, action: 'Schedule an extra cook for these hours.' });
    const popular = new Set(menu.items.filter(i => i.qty > menu.medianQty).map(i => i.name));
    const recipes = await M.Recipe.find().populate('menuItem', 'name').populate('items.ingredient', 'name');
    for (const inv of low.filter(i => i.quantity <= i.minThreshold * 1.5)) {
      const users = recipes.filter(r => r.items.some(x => String(x.ingredient._id) === String(inv.ingredient._id))).map(r => r.menuItem.name).filter(n => popular.has(n));
      if (users.length) await upsertRec({ key: `restock:${id}:${inv.ingredient._id}`, branch: id, title: `Replenish ${inv.ingredient.name}`, priority: inv.quantity <= inv.minThreshold ? 'high' : 'medium',
        reason: `Stock ${inv.quantity.toFixed(1)} vs minimum ${inv.minThreshold}; used by popular items.`, data: { popularItems: users, stock: inv.quantity }, action: 'Raise a purchase order now.' });
    }
    const delayed = await M.Exception.countDocuments({ branch: id, type: 'Order delay', detectedAt: { $gte: since(7) } });
    if (delayed >= 2) await upsertRec({ key: `workflow:${id}`, branch: id, title: 'Review preparation workflow for delayed orders', priority: 'high',
      reason: `${delayed} delay alerts in the last 7 days.`, data: { delayAlerts: delayed }, action: 'Audit slowest stations and the longest-prep items.' });
    menu.items.filter(i => i.trend >= 30 && i.qty >= 5).slice(0, 2).forEach(i => upsertRec({ key: `trend:${id}:${i.id}`, branch: id, title: `${i.name} is trending (+${i.trend}%)`, priority: 'medium',
      reason: 'Sales in the latest half of the window exceed the earlier half.', data: { qty: i.qty, trend: i.trend }, action: 'Feature it on the landing page and stock up.' }));
    menu.items.filter(i => i.class === 'Workhorse').slice(0, 2).forEach(i => upsertRec({ key: `price:${id}:${i.id}`, branch: id, title: `Review price of ${i.name}`, priority: 'medium',
      reason: `High sales, margin only ${(i.margin * 100).toFixed(0)}%.`, data: { price: i.price, unitCost: i.unitCost, margin: i.margin }, action: 'Test a small price rise or reduce portion cost.' }));
    const out = await M.MenuItem.find({ unavailableBranches: id });
    if (out.length) await upsertRec({ key: `avail:${id}`, branch: id, title: `${out.length} item(s) auto-hidden due to stock`, priority: 'medium',
      reason: 'Recipe ingredients are below one serving.', data: { items: out.map(o => o.name) }, action: 'Restock ingredients to restore these items.' });
  }
  return M.Recommendation.find(bf(branch)).sort({ status: 1, createdAt: -1 });
}

// Purchase-order recommendations from low stock
async function purchaseSuggestions(branch) {
  const inv = await M.Inventory.find(bf(branch)).populate('ingredient');
  return inv.filter(i => i.quantity <= i.minThreshold * 1.2).map(i => ({ branch: i.branch, ingredient: i.ingredient._id, name: i.ingredient.name, unit: i.ingredient.unit,
    stock: i.quantity, min: i.minThreshold, suggestedQty: +(i.minThreshold * 3 - i.quantity).toFixed(1) }));
}

module.exports = { menuOptimization, detectExceptions, customerExperience, demandForecast, generateRecommendations, purchaseSuggestions };

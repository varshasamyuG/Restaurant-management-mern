const M = require('../models');
const since = d => new Date(Date.now() - d * 864e5);
// Rule-based RFM-style segmentation from order history
async function segmentCustomers() {
  const users = await M.User.find({ role: 'customer' });
  const out = [];
  for (const u of users) {
    const orders = await M.Order.find({ customer: u._id, status: { $ne: 'Cancelled' } });
    const spent = orders.reduce((s, o) => s + o.total, 0), last = orders.reduce((d, o) => (o.createdAt > d ? o.createdAt : d), new Date(0));
    const seg = !orders.length ? 'New' : last < since(45) ? 'Dormant' : last < since(21) ? 'At-risk' : orders.length >= 6 || spent >= 3000 ? 'Champions' : orders.length >= 3 ? 'Loyal' : 'New';
    await M.Customer.findOneAndUpdate({ user: u._id }, { segment: seg, totalSpent: spent, orderCount: orders.length, lastOrderAt: last }, { upsert: true });
    out.push({ user: u._id, name: u.name, segment: seg, orders: orders.length, spent });
  }
  return out;
}
async function sendCampaign(c, by) {
  const segs = await segmentCustomers();
  const targets = segs.filter(s => c.segment === 'All' || s.segment === c.segment);
  const camp = await M.MarketingCampaign.create({ ...c, sentCount: targets.length, createdBy: by });
  await M.Notification.insertMany(targets.map(t => ({ user: t.user, title: c.title, body: c.message, kind: 'promo', campaign: camp._id })));
  return camp;
}
// Personalised recommendations: customer's most-ordered items, then popular items they have not tried
async function personalized(userId) {
  const mine = await M.Order.find({ customer: userId, status: { $ne: 'Cancelled' } });
  const own = {}; mine.forEach(o => o.items.forEach(l => { own[l.menuItem] = (own[l.menuItem] || 0) + l.qty; }));
  const top = await M.Order.aggregate([{ $unwind: '$items' }, { $group: { _id: '$items.menuItem', q: { $sum: '$items.qty' } } }, { $sort: { q: -1 } }, { $limit: 12 }]);
  const ids = [...Object.keys(own).sort((a, b) => own[b] - own[a]).slice(0, 3), ...top.map(t => String(t._id)).filter(i => !own[i])].slice(0, 6);
  const items = await M.MenuItem.find({ _id: { $in: ids }, isAvailable: true });
  return ids.map(i => items.find(x => String(x._id) === i)).filter(Boolean).map(i => ({ ...i.toObject(), reason: own[i._id] ? 'You ordered this before' : 'Popular with other guests' }));
}
module.exports = { segmentCustomers, sendCampaign, personalized };

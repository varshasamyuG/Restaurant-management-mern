const M = require('../models');
const S = require('../config/settings');
const { httpError } = require('../middleware/auth');

let io = null;
const setIO = s => { io = s; };
const emit = (evt, payload) => io && io.emit(evt, payload);

const nextNumber = async () => `ORD-${Date.now().toString().slice(-7)}${Math.floor(Math.random() * 90 + 10)}`;

// Business flow: price from DB (never trust client prices), tax, discount, persist.
async function createOrder(user, body) {
  const { branch, items = [], type = 'dine-in', table, notes, discount = 0, source = 'online', customerName, deliveryAddress, priority } = body;
  if (!branch) throw httpError(400, 'branch is required');
  if (!items.length) throw httpError(400, 'Order needs at least one item');
  const docs = await M.MenuItem.find({ _id: { $in: items.map(i => i.menuItem) } });
  const lines = items.map(i => {
    const d = docs.find(x => String(x._id) === String(i.menuItem));
    if (!d) throw httpError(400, 'Unknown menu item');
    if (!d.isAvailable || d.unavailableBranches.map(String).includes(String(branch))) throw httpError(409, `${d.name} is currently unavailable`);
    return { menuItem: d._id, name: d.name, price: d.price, qty: Math.max(1, +i.qty || 1), notes: i.notes };
  });
  const subtotal = lines.reduce((s, l) => s + l.price * l.qty, 0);
  const disc = Math.min(+discount || 0, subtotal);
  const tax = +((subtotal - disc) * S.TAX_RATE).toFixed(2);
  const isCustomer = user.role === 'customer';
  const order = await M.Order.create({
    number: await nextNumber(), branch, customer: isCustomer ? user._id : body.customer, customerName: customerName || (isCustomer ? user.name : 'Walk-in'),
    source, type, table, items: lines, notes, priority, subtotal, discount: disc, tax, total: +(subtotal - disc + tax).toFixed(2),
    deliveryAddress, statusHistory: [{ status: 'Received' }]
  });
  emit('order:new', order);
  return order;
}

const FLOW = {
  Received: ['Confirmed', 'Cancelled'], Confirmed: ['Preparing', 'Cancelled'], Preparing: ['Ready', 'Cancelled'],
  Ready: ['Out for Delivery', 'Served', 'Completed'], 'Out for Delivery': ['Completed'], Served: ['Completed'], Completed: [], Cancelled: []
};

async function setStatus(orderId, status) {
  const order = await M.Order.findById(orderId);
  if (!order) throw httpError(404, 'Order not found');
  if (!FLOW[order.status].includes(status)) throw httpError(400, `Cannot move ${order.status} → ${status}`);
  if (status === 'Out for Delivery' && order.type !== 'delivery') throw httpError(400, 'Only delivery orders can go out for delivery');
  order.status = status;
  order.statusHistory.push({ status });
  await order.save();
  if (status === 'Confirmed') await deductInventory(order);      // ingredient consumption workflow
  if (status === 'Completed') await completeOrder(order);
  emit('order:update', order);
  return order;
}

// Recipe-based stock deduction + automatic low-stock exceptions + menu availability sync
async function deductInventory(order) {
  if (order.inventoryDeducted) return;
  const recipes = await M.Recipe.find({ menuItem: { $in: order.items.map(i => i.menuItem) } });
  const need = {};
  for (const it of order.items) {
    const r = recipes.find(x => String(x.menuItem) === String(it.menuItem));
    (r?.items || []).forEach(ri => { need[ri.ingredient] = (need[ri.ingredient] || 0) + ri.qty * it.qty; });
  }
  for (const [ing, qty] of Object.entries(need)) {
    const inv = await M.Inventory.findOneAndUpdate({ branch: order.branch, ingredient: ing }, { $inc: { quantity: -qty } }, { new: true });
    if (!inv) continue;
    await M.InventoryTransaction.create({ branch: order.branch, ingredient: ing, type: 'out', qty, reason: 'Order consumption', order: order._id });
  }
  order.inventoryDeducted = true; await order.save();
  await syncAvailability(order.branch);
  require('./intelligenceService').detectExceptions(order.branch).catch(() => {});
}

// Menu item becomes unavailable at a branch if any recipe ingredient is below the amount for one serving
async function syncAvailability(branch) {
  const inv = await M.Inventory.find({ branch });
  const stock = Object.fromEntries(inv.map(i => [String(i.ingredient), i.quantity]));
  for (const r of await M.Recipe.find()) {
    const short = r.items.some(ri => (stock[String(ri.ingredient)] ?? Infinity) < ri.qty);
    await M.MenuItem.updateOne({ _id: r.menuItem }, short ? { $addToSet: { unavailableBranches: branch } } : { $pull: { unavailableBranches: branch } });
  }
}

async function completeOrder(order) {
  if (order.paymentStatus !== 'Paid' && order.type !== 'delivery') { /* allow pay-later; recorded as Pending */ }
  if (order.customer && !order.pointsAwarded) {
    const pts = Math.floor(order.total / S.LOYALTY_EARN_PER);
    const acc = await M.LoyaltyAccount.findOneAndUpdate({ customer: order.customer }, { $inc: { points: pts } }, { upsert: true, new: true });
    acc.tier = acc.points >= 500 ? 'Gold' : acc.points >= 200 ? 'Silver' : 'Bronze'; await acc.save();
    await M.LoyaltyTransaction.create({ customer: order.customer, points: pts, type: 'earn', reason: `Order ${order.number}`, order: order._id });
    await M.Customer.findOneAndUpdate({ user: order.customer }, { $inc: { totalSpent: order.total, orderCount: 1 }, lastOrderAt: new Date() }, { upsert: true });
    await M.Notification.create({ user: order.customer, title: 'Order completed', body: `You earned ${pts} loyalty points.`, kind: 'loyalty' });
    order.pointsAwarded = true; await order.save();
  }
}

async function recordPayment(orderId, method, userBranchGuard) {
  const order = await M.Order.findById(orderId);
  if (!order) throw httpError(404, 'Order not found');
  if (order.paymentStatus === 'Paid') throw httpError(409, 'Order already paid');
  // DEMO MODE: no real gateway. Every payment is simulated.
  const p = await M.Payment.create({ order: order._id, branch: order.branch, amount: order.total, method, txnId: `DEMO-${Date.now()}`, simulated: true });
  order.paymentStatus = 'Paid'; await order.save();
  emit('order:update', order);
  return p;
}

module.exports = { setIO, emit, createOrder, setStatus, recordPayment, syncAvailability, FLOW };

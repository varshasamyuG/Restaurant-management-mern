import {useState,createContext,useContext} from 'react';
import {Routes,Route,Navigate} from 'react-router-dom';
import Login from './pages/Login.jsx';import Customer from './pages/Customer.jsx';import Staff from './pages/Staff.jsx';
const Ctx=createContext();export const useAuth=()=>useContext(Ctx);
export default function App(){
 const [user,setUser]=useState(()=>JSON.parse(localStorage.getItem('user')||'null'));
 const login=(token,u)=>{localStorage.setItem('token',token);localStorage.setItem('user',JSON.stringify(u));setUser(u)};
 const logout=()=>{localStorage.clear();setUser(null)};
 return <Ctx.Provider value={{user,login,logout}}><Routes>
  <Route path="/login" element={user?<Navigate to="/"/>:<Login/>}/>
  <Route path="/" element={!user?<Navigate to="/login"/>:user.role==='customer'?<Customer/>:<Staff/>}/>
  <Route path="*" element={<Navigate to="/"/>}/></Routes></Ctx.Provider>}

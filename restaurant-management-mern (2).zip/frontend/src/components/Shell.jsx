import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom'; import { useEffect, useState } from 'react';
import { LayoutDashboard, ClipboardList, UtensilsCrossed, Boxes, ChefHat, Receipt, Truck, CalendarDays, Users, Sparkles, AlertTriangle, Lightbulb, Megaphone, Building2, Bell, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext'; import api, { socket } from '../services/api';
const NAV = [['/app', 'Overview', LayoutDashboard, ['admin', 'manager']], ['/app/orders', 'Orders', ClipboardList, ['admin', 'manager']], ['/app/menu', 'Menu & recipes', UtensilsCrossed, ['admin', 'manager']],
  ['/app/inventory', 'Inventory', Boxes, ['admin', 'manager']], ['/app/kitchen', 'Kitchen', ChefHat, ['admin', 'manager', 'kitchen']], ['/app/pos', 'POS', Receipt, ['admin', 'manager']],
  ['/app/delivery', 'Delivery', Truck, ['admin', 'manager', 'delivery']], ['/app/reservations', 'Reservations', CalendarDays, ['admin', 'manager']], ['/app/customers', 'Customers & loyalty', Users, ['admin', 'manager']],
  ['/app/intelligence', 'Smart Intelligence', Sparkles, ['admin', 'manager']], ['/app/exceptions', 'Exceptions', AlertTriangle, ['admin', 'manager']], ['/app/recommendations', 'Recommendations', Lightbulb, ['admin', 'manager']],
  ['/app/marketing', 'Marketing', Megaphone, ['admin', 'manager']], ['/app/branches', 'Branches', Building2, ['admin']]];
export default function Shell() {
  const { user, logout } = useAuth(), nav = useNavigate(), loc = useLocation(), [notes, setNotes] = useState([]), [open, setOpen] = useState(false), [toast, setToast] = useState('');
  useEffect(() => { api.get('/notifications').then(r => setNotes(r.data)).catch(() => {});
    const h = o => { setToast(`New order ${o.number}`); setTimeout(() => setToast(''), 4000); }; socket.on('order:new', h); return () => socket.off('order:new', h); }, []);
  const crumb = NAV.find(n => n[0] === loc.pathname)?.[1] || 'Dashboard';
  return <div className="flex min-h-screen">
    <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-edge bg-panel/60 p-4 md:flex">
      <div className="mb-6 text-lg font-extrabold">Restaurant<span className="text-aqua">OS</span></div>
      <nav className="flex-1 space-y-1 overflow-y-auto">{NAV.filter(n => n[3].includes(user.role)).map(([to, label, Icon]) => <NavLink key={to} to={to} end={to === '/app'}
        className={({ isActive }) => `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium ${isActive ? 'bg-volt text-white' : 'text-slate-300 hover:bg-edge/60'}`}><Icon size={17} />{label}</NavLink>)}</nav>
    </aside>
    <div className="min-w-0 flex-1">
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-edge bg-ink/90 px-5 py-3 backdrop-blur">
        <div className="text-sm text-slate-400">Dashboard / <span className="text-white">{crumb}</span></div>
        <div className="flex items-center gap-3"><div className="relative"><button aria-label="Notifications" className="btn-ghost px-2.5" onClick={() => setOpen(!open)}><Bell size={16} />{notes.some(n => !n.read) && <span className="h-2 w-2 rounded-full bg-aqua" />}</button>
          {open && <div className="card absolute right-0 mt-2 w-72 space-y-2 text-sm">{notes.length ? notes.slice(0, 6).map(n => <div key={n._id}><b>{n.title}</b><div className="text-slate-400">{n.body}</div></div>) : 'No notifications'}</div>}</div>
          <div className="text-right text-xs"><div className="font-semibold">{user.name}</div><div className="text-slate-400">{user.role}</div></div>
          <button aria-label="Log out" className="btn-ghost px-2.5" onClick={() => { logout(); nav('/'); }}><LogOut size={16} /></button></div>
      </header>
      <main className="p-5"><Outlet /></main>
      {toast && <div className="fixed bottom-5 right-5 rounded-xl bg-aqua px-4 py-2 text-sm font-semibold text-ink shadow-xl">{toast}</div>}
    </div></div>;
}

import { useEffect, useState } from 'react'; import api, { errMsg } from '../services/api';
export const Stat = ({ label, value, hint, tone = 'text-white' }) => <div className="card"><div className="text-xs text-slate-400">{label}</div><div className={`mt-1 text-3xl font-extrabold ${tone}`}>{value}</div>{hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}</div>;
const TONES = { critical: 'bg-red-500/20 text-red-300', high: 'bg-orange-500/20 text-orange-300', medium: 'bg-yellow-500/20 text-yellow-200', low: 'bg-sky-500/20 text-sky-200', ok: 'bg-emerald-500/20 text-emerald-300', info: 'bg-blue-500/20 text-blue-200' };
export const Badge = ({ tone = 'info', children }) => <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${TONES[tone] || TONES.info}`}>{children}</span>;
export const statusTone = s => ({ Received: 'info', Confirmed: 'info', Preparing: 'medium', Ready: 'ok', 'Out for Delivery': 'high', Served: 'ok', Completed: 'ok', Cancelled: 'critical' }[s] || 'info');
export const Page = ({ title, sub, actions, children }) => <div className="space-y-5"><div className="flex flex-wrap items-end justify-between gap-3"><div><h1 className="text-2xl font-extrabold">{title}</h1>{sub && <p className="text-sm text-slate-400">{sub}</p>}</div><div className="flex gap-2">{actions}</div></div>{children}</div>;
export const Table = ({ cols, rows, empty = 'Nothing here yet.' }) => <div className="card overflow-x-auto p-0"><table className="w-full"><thead><tr>{cols.map(c => <th key={c.h} className="th">{c.h}</th>)}</tr></thead><tbody>
  {rows.map((r, i) => <tr key={r._id || i}>{cols.map(c => <td key={c.h} className="td">{c.r(r)}</td>)}</tr>)}{!rows.length && <tr><td className="td text-slate-500" colSpan={cols.length}>{empty}</td></tr>}</tbody></table></div>;
export function useFetch(url, deps = []) {
  const [data, setData] = useState(null), [error, setError] = useState(''), [loading, setLoading] = useState(true);
  const load = () => { setLoading(true); return api.get(url).then(r => { setData(r.data); setError(''); }).catch(e => setError(errMsg(e))).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, [url, ...deps]);
  return { data, error, loading, reload: load, setData };
}
export const Async = ({ f, children }) => f.loading && !f.data ? <div className="text-slate-400">Loading…</div> : f.error ? <div className="card border-red-500/40 text-red-300">{f.error}</div> : children(f.data);

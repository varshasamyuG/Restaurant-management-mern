import { createContext, useContext, useEffect, useState } from 'react'; import api from '../services/api';
const Ctx = createContext(); export const useAuth = () => useContext(Ctx);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null), [ready, setReady] = useState(false);
  useEffect(() => { if (!localStorage.getItem('rms_token')) return setReady(true); api.get('/auth/me').then(r => setUser(r.data.user)).catch(() => localStorage.removeItem('rms_token')).finally(() => setReady(true)); }, []);
  const login = async (email, password) => { const { data } = await api.post('/auth/login', { email, password }); localStorage.setItem('rms_token', data.token); setUser(data.user); return data.user; };
  const register = async f => { const { data } = await api.post('/auth/register', f); localStorage.setItem('rms_token', data.token); setUser(data.user); return data.user; };
  const logout = () => { localStorage.removeItem('rms_token'); setUser(null); };
  return <Ctx.Provider value={{ user, ready, login, register, logout }}>{children}</Ctx.Provider>;
}

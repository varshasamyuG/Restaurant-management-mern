import { useState } from 'react'; import { Link, useNavigate } from 'react-router-dom'; import { useAuth } from '../context/AuthContext'; import { errMsg } from '../services/api';
const home = r => (r === 'customer' ? '/account' : r === 'kitchen' ? '/app/kitchen' : r === 'delivery' ? '/app/delivery' : '/app');
function Form({ mode }) {
  const { login, register } = useAuth(), nav = useNavigate(), [f, setF] = useState({ name: '', email: '', password: '' }), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const submit = async e => { e.preventDefault(); setBusy(true); setErr(''); try { const u = mode === 'login' ? await login(f.email, f.password) : await register(f); nav(home(u.role)); } catch (x) { setErr(errMsg(x)); } setBusy(false); };
  const demo = [['Admin', 'admin@rms.com'], ['Manager', 'manager@rms.com'], ['Kitchen', 'kitchen@rms.com'], ['Delivery', 'delivery@rms.com'], ['Customer', 'customer@rms.com']];
  return <div className="flex min-h-screen items-center justify-center p-4"><form onSubmit={submit} className="card w-full max-w-md space-y-4">
    <h1 className="text-2xl font-extrabold">{mode === 'login' ? 'Sign in' : 'Create your account'}</h1>
    {mode === 'register' && <input className="input" placeholder="Full name" value={f.name} onChange={set('name')} required />}
    <input className="input" type="email" placeholder="Email" value={f.email} onChange={set('email')} required />
    <input className="input" type="password" placeholder="Password (min 6 characters)" value={f.password} onChange={set('password')} required />
    {err && <div className="text-sm text-red-300">{err}</div>}
    <button className="btn w-full" disabled={busy}>{mode === 'login' ? 'Sign in' : 'Register'}</button>
    {mode === 'login' && <div className="space-y-2 border-t border-edge pt-3 text-xs text-slate-400">Demo accounts (password Password@123):<div className="flex flex-wrap gap-2">{demo.map(([l, e]) => <button type="button" key={e} className="btn-ghost px-2 py-1 text-xs" onClick={() => setF({ ...f, email: e, password: 'Password@123' })}>{l}</button>)}</div></div>}
    <div className="text-sm text-slate-400">{mode === 'login' ? <>New here? <Link className="text-aqua" to="/register">Create an account</Link></> : <>Have an account? <Link className="text-aqua" to="/login">Sign in</Link></>}</div></form></div>;
}
export const Login = () => <Form mode="login" />; export const Register = () => <Form mode="register" />;

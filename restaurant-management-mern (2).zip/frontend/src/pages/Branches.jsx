import { useState } from 'react'; import api, { errMsg } from '../services/api'; import { Async, Badge, Page, Table, useFetch } from '../components/ui';
export default function Branches() {
  const f = useFetch('/branches'), u = useFetch('/users'), [b, setB] = useState({ name: '', code: '', address: '', area: '' });
  const add = async () => { try { await api.post('/branches', b); setB({ name: '', code: '', address: '', area: '' }); f.reload(); } catch (e) { alert(errMsg(e)); } };
  return <Page title="Branches & users" sub="Managers, kitchen and delivery staff only see data for their own branch."><div className="card flex flex-wrap gap-2">{['name', 'code', 'address', 'area'].map(k => <input key={k} className="input w-40" placeholder={k} value={b[k]} onChange={e => setB({ ...b, [k]: e.target.value })} />)}<button className="btn" onClick={add}>Register branch</button></div>
    <Async f={f}>{d => <Table rows={d} cols={[{ h: 'Branch', r: x => <b>{x.name}</b> }, { h: 'Code', r: x => x.code }, { h: 'Address', r: x => x.address }, { h: 'Area', r: x => x.area }]} />}</Async>
    <Async f={u}>{d => <Table rows={d} cols={[{ h: 'User', r: x => x.name }, { h: 'Email', r: x => x.email }, { h: 'Role', r: x => <Badge>{x.role}</Badge> }, { h: 'Branch', r: x => x.branch?.name || '-' }]} />}</Async></Page>;
}

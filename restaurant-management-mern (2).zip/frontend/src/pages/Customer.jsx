import {useEffect,useState} from 'react';import {io} from 'socket.io-client';import {ShoppingCart,LogOut,Star} from 'lucide-react';
import api,{err} from '../api.js';import {useAuth} from '../App.jsx';
const STEPS=['Received','Confirmed','Preparing','Ready','Out for Delivery','Served','Completed'];
export default function Customer(){const {user,logout}=useAuth();const [tab,setTab]=useState('menu'),[menu,setMenu]=useState([]),[q,setQ]=useState(''),[cat,setCat]=useState('All'),[cart,setCart]=useState({}),
 [orders,setOrders]=useState([]),[opt,setOpt]=useState({type:'dine-in',table:'T1',address:'',paymentMethod:'UPI'}),[msg,setMsg]=useState(''),[pts,setPts]=useState(user.loyaltyPoints);
 const table=new URLSearchParams(location.search).get('table'); // QR: /?table=T5
 const loadO=()=>api.get('/orders').then(r=>setOrders(r.data));
 useEffect(()=>{api.get('/menu',{params:{branch:user.branch}}).then(r=>setMenu(r.data));loadO();if(table)setOpt(o=>({...o,table}));
  const s=io();s.on('order:update',()=>{loadO();api.get('/auth/me').then(r=>setPts(r.data.loyaltyPoints))});return()=>s.close()},[]);
 const cats=['All',...new Set(menu.map(m=>m.category))],shown=menu.filter(m=>(cat==='All'||m.category===cat)&&m.name.toLowerCase().includes(q.toLowerCase()));
 const lines=Object.entries(cart).map(([id,qty])=>({m:menu.find(x=>x._id===id),qty})),sub=lines.reduce((a,l)=>a+l.m.price*l.qty,0);
 const place=async()=>{try{await api.post('/orders',{...opt,items:lines.map(l=>({menuItem:l.m._id,qty:l.qty}))});setCart({});setMsg('Order placed. Payment was simulated (demo mode).');setTab('orders');loadO()}catch(x){setMsg(err(x))}};
 const rate=async(o,rating)=>{await api.post('/feedback',{order:o._id,rating});setMsg('Thanks for your feedback')};
 return <div className="mx-auto max-w-6xl p-4"><header className="flex flex-wrap items-center justify-between gap-3"><div><h1 className="text-2xl font-extrabold">Hello, {user.name}</h1><p className="text-sm text-slate-400">Loyalty points: <b className="text-aqua">{pts}</b>{table&&` · Ordering from table ${table}`}</p></div>
  <div className="flex gap-2"><button className={tab==='menu'?'btn':'btn2'} onClick={()=>setTab('menu')}>Menu</button><button className={tab==='orders'?'btn':'btn2'} onClick={()=>setTab('orders')}>My orders</button><button className="btn2" onClick={logout}><LogOut size={16}/></button></div></header>
  {msg&&<p className="mt-3 rounded-lg bg-white/5 p-2 text-sm">{msg}</p>}
  {tab==='menu'?<div className="mt-5 grid gap-5 lg:grid-cols-[1fr_340px]"><div>
   <div className="flex flex-wrap gap-2"><input className="inp max-w-xs" placeholder="Search dishes" value={q} onChange={e=>setQ(e.target.value)}/>{cats.map(c=><button key={c} className={c===cat?'btn':'btn2'} onClick={()=>setCat(c)}>{c}</button>)}</div>
   <div className="mt-4 grid gap-3 sm:grid-cols-2">{shown.map(m=><div key={m._id} className="card flex flex-col justify-between"><div><div className="flex justify-between"><b>{m.name}</b><span className="text-aqua">₹{m.price}</span></div><p className="mt-1 text-xs text-slate-400">{m.category} · {m.description}</p></div>
    <button className="btn mt-3" disabled={!m.inStock||!m.available} onClick={()=>setCart({...cart,[m._id]:(cart[m._id]||0)+1})}>{m.inStock?'Add to cart':'Out of stock'}</button></div>)}</div></div>
   <aside className="card h-fit"><h2 className="flex items-center gap-2 font-bold"><ShoppingCart size={18}/>Cart</h2>
    {!lines.length&&<p className="mt-3 text-sm text-slate-400">Add dishes from the menu to start an order.</p>}
    {lines.map(l=><div key={l.m._id} className="mt-2 flex items-center justify-between text-sm"><span>{l.m.name}</span><span className="flex items-center gap-2"><button className="btn2 px-2 py-0" onClick={()=>setCart(c=>{const n={...c,[l.m._id]:c[l.m._id]-1};if(!n[l.m._id])delete n[l.m._id];return n})}>-</button>{l.qty}<button className="btn2 px-2 py-0" onClick={()=>setCart({...cart,[l.m._id]:l.qty+1})}>+</button></span></div>)}
    {!!lines.length&&<div className="mt-4 space-y-2"><select className="inp" value={opt.type} onChange={e=>setOpt({...opt,type:e.target.value})}><option value="dine-in">Dine-in</option><option value="takeaway">Takeaway</option><option value="delivery">Delivery</option></select>
     {opt.type==='dine-in'&&<input className="inp" placeholder="Table" value={opt.table} onChange={e=>setOpt({...opt,table:e.target.value})}/>}
     {opt.type==='delivery'&&<input className="inp" placeholder="Delivery address" value={opt.address} onChange={e=>setOpt({...opt,address:e.target.value})}/>}
     <select className="inp" value={opt.paymentMethod} onChange={e=>setOpt({...opt,paymentMethod:e.target.value})}>{['UPI','Card','Online','Cash'].map(p=><option key={p}>{p}</option>)}</select>
     <p className="text-sm text-slate-400">Subtotal ₹{sub} · GST 5% ₹{(sub*.05).toFixed(2)}</p><p className="font-bold">Total ₹{(sub*1.05).toFixed(2)}</p><button className="btn w-full" onClick={place}>Place order (demo payment)</button></div>}</aside></div>
  :<div className="mt-5 space-y-3">{!orders.length&&<p className="text-slate-400">No orders yet.</p>}{orders.map(o=>{const i=STEPS.indexOf(o.status);return <div key={o._id} className="card"><div className="flex justify-between"><b>Order #{o.number}</b><span className="badge bg-volt/20 text-aqua">{o.status}</span></div>
   <p className="mt-1 text-sm text-slate-400">{o.items.map(x=>`${x.qty}× ${x.name}`).join(', ')} · ₹{o.total} · {o.paymentStatus}</p>
   <div className="mt-3 flex gap-1">{STEPS.map((s,k)=><div key={s} title={s} className={`h-1.5 flex-1 rounded ${k<=i?'bg-aqua':'bg-white/10'}`}/>)}</div>
   {o.status==='Completed'&&<div className="mt-3 flex items-center gap-1 text-sm">Rate:{[1,2,3,4,5].map(n=><button key={n} onClick={()=>rate(o,n)}><Star size={18} className="text-yellow-400"/></button>)}</div>}</div>})}</div>}</div>}

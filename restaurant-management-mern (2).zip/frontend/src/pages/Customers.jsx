import { Async, Badge, Page, Table, useFetch } from '../components/ui'; import { money } from '../services/api';
export default function Customers() {
  const f = useFetch('/customers'); return <Page title="Customers & loyalty" sub="Points: 1 per ₹10 spent on completed orders. Silver 200+, Gold 500+."><Async f={f}>{d => <Table rows={d} cols={[{ h: 'Customer', r: c => <b>{c.user?.name}</b> }, { h: 'Email', r: c => c.user?.email }, { h: 'Orders', r: c => c.orderCount }, { h: 'Spent', r: c => money(c.totalSpent) }, { h: 'Segment', r: c => <Badge>{c.segment}</Badge> }]} />}</Async></Page>;
}

import { useState } from 'react'; import api, { errMsg } from '../services/api'; import { useAuth } from '../context/AuthContext'; import { Async, Badge, Page, Table, useFetch } from '../components/ui';
const NEXT = { Assigned: 'Accepted', Accepted: 'PickedUp', PickedUp: 'Delivered' }, LABEL = { Assigned: 'Accept delivery', Accepted: 'Mark picked up', PickedUp: 'Mark delivered' };
export default function Delivery() {
  const { user } = useAuth(), isDriver = user.role === 'delivery', d = useFetch('/deliveries'), p = useFetch(isDriver ? '/auth/me' : '/deliveries/pending'), [pick, setPick] = useState({});
  const reload = () => { d.reload(); !isDriver && p.reload(); };
  const step = async x => { try { await api.patch(`/deliveries/${x._id}/status`, { status: NEXT[x.status] }); reload(); } catch (e) { alert(errMsg(e)); } };
  const assign = async (o, driver) => { try { await api.post('/deliveries/assign', { order: o._id, driver }); reload(); } catch (e) { alert(errMsg(e)); } };
  return <Page title={isDriver ? 'My deliveries' : 'Delivery management'} sub={isDriver ? 'Accept, pick up and deliver your assigned orders.' : 'Delivery orders are grouped by area so one driver can take nearby drops.'}>
    {!isDriver && <Async f={p}>{x => <div className="grid gap-3 md:grid-cols-2">{x.groups.map(g => <div key={g.area} className="card"><div className="mb-2 font-bold">{g.area} <span className="text-sm text-slate-400">({g.orders.length} unassigned)</span></div>
      {g.orders.map(o => <div key={o._id} className="flex items-center justify-between gap-2 border-t border-edge py-2 text-sm"><span>{o.number} · {o.deliveryAddress?.line}</span>
        <select className="input w-32 py-1" value={pick[o._id] || ''} onChange={e => setPick({ ...pick, [o._id]: e.target.value })}><option value="">Driver</option>{x.drivers.map(dr => <option key={dr._id} value={dr._id}>{dr.name}</option>)}</select>
        <button className="btn px-2 py-1 text-xs" disabled={!pick[o._id]} onClick={() => assign(o, pick[o._id])}>Assign</button></div>)}</div>)}{!x.groups.length && <div className="card text-sm text-slate-500">No unassigned delivery orders.</div>}</div>}</Async>}
    <Async f={d}>{rows => <Table rows={rows} empty="No deliveries." cols={[{ h: 'Order', r: r => <b>{r.order?.number}</b> }, { h: 'Customer', r: r => r.order?.customerName }, { h: 'Address', r: r => `${r.address || ''} (${r.area || '-'})` }, { h: 'Driver', r: r => r.driver?.name },
      { h: 'Status', r: r => <Badge tone={r.status === 'Delivered' ? 'ok' : 'medium'}>{r.status}</Badge> }, { h: '', r: r => NEXT[r.status] && <button className="btn px-2 py-1 text-xs" onClick={() => step(r)}>{LABEL[r.status]}</button> }]} />}</Async></Page>;
}

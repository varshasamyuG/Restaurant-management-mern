import { useState } from 'react'; import api, { errMsg } from '../services/api'; import { Async, Badge, Page, Table, useFetch } from '../components/ui';
export default function Exceptions() {
  const [show, setShow] = useState('false'), f = useFetch(`/intelligence/exceptions?resolved=${show}`, [show]);
  const resolve = async x => { try { await api.patch(`/intelligence/exceptions/${x._id}/resolve`); f.reload(); } catch (e) { alert(errMsg(e)); } };
  return <Page title="Exception monitor" sub="Rule-based detection: order delays, stuck orders, kitchen bottlenecks, long prep times, low stock and stock discrepancies." actions={<><button className={show === 'false' ? 'btn' : 'btn-ghost'} onClick={() => setShow('false')}>Open</button><button className={show === 'true' ? 'btn' : 'btn-ghost'} onClick={() => setShow('true')}>Resolved</button></>}>
    <Async f={f}>{d => <Table rows={d} empty="No exceptions in this view." cols={[{ h: 'Type', r: x => <b>{x.type}</b> }, { h: 'Related', r: x => x.order?.number || x.ingredient?.name || x.branch?.name }, { h: 'Detected', r: x => new Date(x.detectedAt).toLocaleString() }, { h: 'Severity', r: x => <Badge tone={x.severity}>{x.severity}</Badge> },
      { h: 'Description', r: x => x.description }, { h: 'Suggested action', r: x => <span className="text-aqua">{x.action}</span> }, { h: 'Status', r: x => x.resolved ? <Badge tone="ok">Resolved</Badge> : <button className="btn px-2 py-1 text-xs" onClick={() => resolve(x)}>Mark resolved</button> }]} />}</Async></Page>;
}

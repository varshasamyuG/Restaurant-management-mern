import { useState } from 'react'; import api, { errMsg } from '../services/api'; import { Async, Badge, Page, Stat, Table, useFetch } from '../components/ui';
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
export default function Inventory() {
  const inv = useFetch('/inventory'), al = useFetch('/inventory/alerts'), hist = useFetch('/inventory/history'), waste = useFetch('/waste'), [tab, setTab] = useState('stock');
  const reload = () => { inv.reload(); al.reload(); hist.reload(); waste.reload(); };
  const adj = async (r, type) => { const qty = +prompt(`${type === 'in' ? 'Stock in' : type === 'waste' ? 'Waste' : 'Stock out'} quantity (${r.ingredient.unit})`); if (!qty) return;
    const wasteReason = type === 'waste' ? prompt('Reason: expired, spoiled, prep-error, spillage, other', 'expired') : undefined;
    try { await api.patch(`/inventory/${r._id}`, { type, qty, reason: wasteReason || 'Manual', wasteReason }); reload(); } catch (e) { alert(errMsg(e)); } };
  const po = async s => { try { await api.post('/purchase-orders', { branch: s.branch, items: [{ ingredient: s.ingredient, qty: s.suggestedQty }] }); alert('Purchase order raised'); } catch (e) { alert(errMsg(e)); } };
  return <Page title="Inventory" sub="Stock deducts automatically when an order is confirmed.">
    <div className="flex gap-2">{['stock', 'alerts', 'history', 'waste'].map(t => <button key={t} className={tab === t ? 'btn' : 'btn-ghost'} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)}</button>)}</div>
    {tab === 'stock' && <Async f={inv}>{d => <Table rows={d} cols={[{ h: 'Branch', r: r => r.branch?.name }, { h: 'Ingredient', r: r => <b>{r.ingredient.name}</b> }, { h: 'Stock', r: r => `${r.quantity.toFixed(1)} ${r.ingredient.unit}` }, { h: 'Minimum', r: r => r.minThreshold },
      { h: 'State', r: r => r.quantity <= r.minThreshold ? <Badge tone="critical">Low</Badge> : <Badge tone="ok">OK</Badge> },
      { h: 'Actions', r: r => <div className="flex gap-1"><button className="btn px-2 py-1 text-xs" onClick={() => adj(r, 'in')}>Stock in</button><button className="btn-ghost px-2 py-1 text-xs" onClick={() => adj(r, 'out')}>Out</button><button className="btn-ghost px-2 py-1 text-xs" onClick={() => adj(r, 'waste')}>Waste</button></div> }]} />}</Async>}
    {tab === 'alerts' && <Async f={al}>{d => <><Stat label="Active low-stock alerts" value={d.alerts.length} tone="text-orange-300" /><div className="font-bold">Purchase order recommendations</div>
      <Table rows={d.purchaseSuggestions} empty="No purchases needed." cols={[{ h: 'Ingredient', r: s => s.name }, { h: 'Stock', r: s => `${s.stock.toFixed(1)} ${s.unit}` }, { h: 'Suggested order', r: s => `${s.suggestedQty} ${s.unit}` }, { h: '', r: s => <button className="btn px-2 py-1 text-xs" onClick={() => po(s)}>Raise PO</button> }]} /></>}</Async>}
    {tab === 'history' && <Async f={hist}>{d => <Table rows={d} cols={[{ h: 'When', r: r => new Date(r.createdAt).toLocaleString() }, { h: 'Ingredient', r: r => r.ingredient?.name }, { h: 'Type', r: r => <Badge tone={r.type === 'in' ? 'ok' : 'medium'}>{r.type}</Badge> }, { h: 'Qty', r: r => r.qty.toFixed(2) }, { h: 'Reason', r: r => r.reason }]} />}</Async>}
    {tab === 'waste' && <Async f={waste}>{d => <><Stat label="Total waste cost" value={`₹${d.totalCost}`} /><div className="card h-64"><ResponsiveContainer><BarChart data={d.byReason}><XAxis dataKey="reason" stroke="#7b8bb0" /><YAxis stroke="#7b8bb0" /><Tooltip contentStyle={{ background: '#0e1a36', border: '1px solid #1b2c52' }} /><Bar dataKey="cost" fill="#2f6bff" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></>}</Async>}</Page>;
}

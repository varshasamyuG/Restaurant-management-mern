import { useEffect, useState } from 'react'; import api, { errMsg, socket } from '../services/api'; import { Page, useFetch } from '../components/ui';
const NEXT = { Received: 'Confirmed', Confirmed: 'Preparing', Preparing: 'Ready' }, LABEL = { Received: 'Accept order', Confirmed: 'Start preparing', Preparing: 'Mark ready' };
export default function Kitchen() {
  const f = useFetch('/kitchen/orders'), [, tick] = useState(0);
  useEffect(() => { const a = setInterval(() => tick(x => x + 1), 15000), b = setInterval(f.reload, 15000); socket.on('order:new', f.reload); socket.on('order:update', f.reload); return () => { clearInterval(a); clearInterval(b); socket.off('order:new', f.reload); socket.off('order:update', f.reload); }; }, []);
  const go = async o => { try { await api.patch(`/kitchen/orders/${o._id}/status`, { status: NEXT[o.status] }); } catch (e) { alert(errMsg(e)); } };
  const cols = ['Received', 'Confirmed', 'Preparing', 'Ready'], list = f.data || [];
  return <Page title="Kitchen display" sub="Oldest tickets first. Red cards are past the delay threshold."><div className="grid gap-4 lg:grid-cols-4">{cols.map(c => <div key={c}><div className="mb-2 text-sm font-bold text-slate-300">{c === 'Received' ? 'New' : c} ({list.filter(o => o.status === c).length})</div><div className="space-y-3">
    {list.filter(o => o.status === c).map(o => <div key={o._id} className={`rounded-2xl border-2 p-4 ${o.delayed ? 'border-red-500 bg-red-950/40' : 'border-edge bg-panel'}`}>
      <div className="flex items-center justify-between"><div className="text-xl font-extrabold">{o.number.slice(-6)}</div><div className={`text-lg font-bold ${o.delayed ? 'text-red-300' : 'text-aqua'}`}>{o.elapsedMin}m</div></div>
      <div className="text-xs text-slate-400">{o.type}{o.table ? ` · Table ${o.table.number}` : ''}{o.priority === 'high' && <b className="ml-2 text-orange-300">PRIORITY</b>}{o.delayed && <b className="ml-2 text-red-300">DELAYED</b>}</div>
      <ul className="mt-2 space-y-1 text-lg font-semibold">{o.items.map((i, k) => <li key={k}>{i.qty}× {i.name}{i.notes && <div className="text-sm font-normal text-yellow-200">Note: {i.notes}</div>}</li>)}</ul>
      {o.notes && <div className="mt-1 text-sm text-yellow-200">Order note: {o.notes}</div>}
      {NEXT[o.status] ? <button className="btn mt-3 w-full py-3 text-base" onClick={() => go(o)}>{LABEL[o.status]}</button> : <div className="mt-3 text-sm text-emerald-300">Waiting for pickup or service</div>}</div>)}</div></div>)}</div></Page>;
}

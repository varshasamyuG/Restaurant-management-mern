import { Link } from 'react-router-dom';
export default function Landing() {
  return <div className="min-h-screen bg-[radial-gradient(ellipse_at_top_right,#12306e,transparent_55%)]">
    <header className="mx-auto flex max-w-6xl items-center justify-between p-6"><div className="text-lg font-extrabold">Restaurant<span className="text-aqua">OS</span></div>
      <div className="flex gap-2"><Link to="/menu" className="btn-ghost">View menu</Link><Link to="/login" className="btn">Sign in</Link></div></header>
    <section className="mx-auto max-w-6xl px-6 pb-16 pt-14">
      <h1 className="max-w-3xl text-5xl font-extrabold leading-tight">From the menu to the doorstep, every order in one place.</h1>
      <p className="mt-5 max-w-xl text-lg text-slate-300">Order dine-in, takeaway or delivery. Kitchen, billing, stock and delivery all see the same order the moment you place it.</p>
      <div className="mt-8 flex gap-3"><Link to="/menu" className="btn px-6 py-3">Order now</Link><Link to="/register" className="btn-ghost px-6 py-3">Create account</Link></div>
      <div className="mt-16 grid gap-4 md:grid-cols-3">{[['Live order tracking', 'Watch your order move from Received to Ready.'], ['Loyalty rewards', 'Earn a point for every ₹10 and redeem them on later orders.'], ['Table booking', 'Reserve a table without double bookings.']].map(([t, d]) => <div key={t} className="card"><div className="font-bold">{t}</div><p className="mt-1 text-sm text-slate-400">{d}</p></div>)}</div>
    </section></div>;
}

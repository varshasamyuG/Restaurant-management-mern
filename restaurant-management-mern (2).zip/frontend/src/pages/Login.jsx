import {useState} from 'react';import api,{err} from '../api.js';import {useAuth} from '../App.jsx';
const DEMO=[['Admin','admin@rms.com'],['Manager','manager@rms.com'],['Kitchen','kitchen@rms.com'],['Delivery','delivery@rms.com'],['Customer','customer@rms.com']];
export default function Login(){const {login}=useAuth();const [reg,setReg]=useState(false),[f,setF]=useState({name:'',email:'',password:'password123'}),[e,setE]=useState('');
 const go=async ev=>{ev.preventDefault();try{const {data}=await api.post('/auth/'+(reg?'register':'login'),f);login(data.token,data.user)}catch(x){setE(err(x))}};
 return <div className="grid min-h-screen place-items-center p-4"><div className="w-full max-w-md">
  <h1 className="text-3xl font-extrabold tracking-tight">Menu to delivery, in one system.</h1>
  <p className="mt-2 text-slate-400">Integrated Restaurant Management System</p>
  <form onSubmit={go} className="card mt-6 space-y-3">
   {reg&&<input className="inp" placeholder="Full name" value={f.name} onChange={x=>setF({...f,name:x.target.value})}/>}
   <input className="inp" placeholder="Email" value={f.email} onChange={x=>setF({...f,email:x.target.value})}/>
   <input className="inp" type="password" placeholder="Password" value={f.password} onChange={x=>setF({...f,password:x.target.value})}/>
   {e&&<p className="text-sm text-red-400">{e}</p>}
   <button className="btn w-full py-2">{reg?'Create account':'Sign in'}</button>
   <button type="button" className="text-sm text-aqua" onClick={()=>setReg(!reg)}>{reg?'I already have an account':'New customer? Register'}</button></form>
  <div className="mt-4 text-sm text-slate-400">Demo accounts (password <b>password123</b>):<div className="mt-2 flex flex-wrap gap-2">{DEMO.map(([n,m])=><button key={m} className="btn2" onClick={()=>{setReg(false);setF({...f,email:m,password:'password123'})}}>{n}</button>)}</div></div></div></div>}

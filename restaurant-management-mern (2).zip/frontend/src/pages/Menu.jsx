import { useEffect, useState } from 'react'; import { Link, useNavigate, useSearchParams } from 'react-router-dom'; import { Minus, Plus, ShoppingCart } from 'lucide-react';
import api, { errMsg, money } from '../services/api'; import { useAuth } from '../context/AuthContext';
export default function Menu() {
  const [sp] = useSearchParams(), nav = useNavigate(), { user } = useAuth();
  const [branches, setBranches] = useState([]), [branch, setBranch] = useState(sp.get('branch') || ''), [cats, setCats] = useState([]), [items, setItems] = useState([]);
  const [q, setQ] = useState(''), [cat, setCat] = useState(''), [veg, setVeg] = useState(''), [cart, setCart] = useState({}), [type, setType] = useState(sp.get('table') ? 'dine-in' : 'takeaway');
  const [notes, setNotes] = useState({}), [addr, setAddr] = useState({ line: '', area: '' }), [method, setMethod] = useState('upi'), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false), [recs, setRecs] = useState([]);
  useEffect(() => { api.get('/branches').then(r => { setBranches(r.data); if (!branch && r.data[0]) setBranch(r.data[0]._id); }); api.get('/categories').then(r => setCats(r.data)); }, []);
  useEffect(() => { if (branch) api.get('/menu', { params: { branch, q, category: cat, veg } }).then(r => setItems(r.data)); }, [branch, q, cat, veg]);
  useEffect(() => { if (user?.role === 'customer') api.get('/marketing/recommended-for-me').then(r => setRecs(r.data)).catch(() => {}); }, [user]);
  const lines = items.filter(i => cart[i._id]), sub = lines.reduce((s, i) => s + i.price * cart[i._id], 0), tax = sub * 0.05;
  const add = (id, d) => setCart(c => { const n = (c[id] || 0) + d; const x = { ...c }; n <= 0 ? delete x[id] : (x[id] = n); return x; });
  const place = async () => {
    if (!user) return nav('/login'); if (user.role !== 'customer') return setMsg('Sign in as a customer to order, or use the POS.');
    setBusy(true); setMsg('');
    try {
      const { data: o } = await api.post('/orders', { branch, type, table: sp.get('table') || undefined, source: sp.get('table') ? 'qr' : 'online', deliveryAddress: type === 'delivery' ? addr : undefined,
        items: lines.map(i => ({ menuItem: i._id, qty: cart[i._id], notes: notes[i._id] })) });
      await api.post('/payments', { order: o._id, method });   // simulated payment (demo mode)
      nav('/account');
    } catch (e) { setMsg(errMsg(e)); } setBusy(false);
  };
  return <div className="mx-auto max-w-7xl p-4 md:p-6"><div className="mb-5 flex items-center justify-between"><Link to="/" className="text-lg font-extrabold">Restaurant<span className="text-aqua">OS</span></Link>
    <div className="flex gap-2">{user ? <Link className="btn-ghost" to={user.role === 'customer' ? '/account' : '/app'}>{user.name}</Link> : <Link className="btn" to="/login">Sign in</Link>}</div></div>
    {sp.get('table') && <div className="card mb-4 border-aqua/50 text-sm">Table ordering enabled. Your order will be linked to your table.</div>}
    <div className="grid gap-6 lg:grid-cols-[1fr_340px]"><div>
      <div className="mb-4 flex flex-wrap gap-2"><select className="input w-auto" value={branch} onChange={e => { setBranch(e.target.value); setCart({}); }}>{branches.map(b => <option key={b._id} value={b._id}>{b.name}</option>)}</select>
        <input className="input w-48" placeholder="Search dishes" value={q} onChange={e => setQ(e.target.value)} />
        <select className="input w-auto" value={cat} onChange={e => setCat(e.target.value)}><option value="">All categories</option>{cats.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}</select>
        <select className="input w-auto" value={veg} onChange={e => setVeg(e.target.value)}><option value="">Veg & non-veg</option><option value="true">Vegetarian</option><option value="false">Non-vegetarian</option></select></div>
      {recs.length > 0 && <div className="mb-5"><div className="mb-2 text-sm font-bold">Picked for you</div><div className="flex gap-2 overflow-x-auto">{recs.map(r => <div key={r._id} className="card min-w-44 shrink-0 p-3 text-sm"><b>{r.name}</b><div className="text-xs text-slate-400">{r.reason}</div></div>)}</div></div>}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{items.map(i => <div key={i._id} className={`card flex flex-col p-4 ${i.available ? '' : 'opacity-50'}`}>
        <div className="flex items-start justify-between gap-2"><div className="font-bold">{i.name}</div><span className={`mt-1 h-3 w-3 shrink-0 rounded-sm border-2 ${i.veg ? 'border-emerald-400' : 'border-red-400'}`} title={i.veg ? 'Veg' : 'Non-veg'} /></div>
        <div className="text-xs text-slate-400">{i.category?.name} · {i.prepMinutes} min</div><p className="mt-2 flex-1 text-sm text-slate-300">{i.description}</p>
        <div className="mt-3 flex items-center justify-between"><b>{money(i.price)}</b>{!i.available ? <span className="text-xs text-orange-300">Unavailable</span> : cart[i._id] ?
          <div className="flex items-center gap-2"><button aria-label="Remove one" className="btn-ghost px-2 py-1" onClick={() => add(i._id, -1)}><Minus size={14} /></button>{cart[i._id]}<button aria-label="Add one" className="btn px-2 py-1" onClick={() => add(i._id, 1)}><Plus size={14} /></button></div> :
          <button className="btn px-3 py-1.5" onClick={() => add(i._id, 1)}>Add</button>}</div></div>)}</div></div>
    <aside className="card h-fit space-y-3 lg:sticky lg:top-4"><div className="flex items-center gap-2 font-bold"><ShoppingCart size={18} /> Your order</div>
      {!lines.length && <div className="text-sm text-slate-400">Add dishes to start an order.</div>}
      {lines.map(i => <div key={i._id} className="space-y-1 text-sm"><div className="flex justify-between"><span>{cart[i._id]} × {i.name}</span><span>{money(i.price * cart[i._id])}</span></div>
        <input className="input py-1 text-xs" placeholder="Special instructions" value={notes[i._id] || ''} onChange={e => setNotes({ ...notes, [i._id]: e.target.value })} /></div>)}
      {lines.length > 0 && <><div className="border-t border-edge pt-2 text-sm"><div className="flex justify-between"><span>Subtotal</span>{money(sub)}</div><div className="flex justify-between"><span>Tax (5%)</span>{money(tax)}</div><div className="flex justify-between text-base font-bold"><span>Total</span>{money(sub + tax)}</div></div>
        <select className="input" value={type} onChange={e => setType(e.target.value)}><option value="dine-in">Dine-in</option><option value="takeaway">Takeaway</option><option value="delivery">Delivery</option></select>
        {type === 'delivery' && <><input className="input" placeholder="Delivery address" value={addr.line} onChange={e => setAddr({ ...addr, line: e.target.value })} /><input className="input" placeholder="Area (e.g. Downtown)" value={addr.area} onChange={e => setAddr({ ...addr, area: e.target.value })} /></>}
        <select className="input" value={method} onChange={e => setMethod(e.target.value)}>{['upi', 'card', 'cash', 'online'].map(m => <option key={m} value={m}>{m.toUpperCase()}</option>)}</select>
        <div className="text-xs text-slate-500">Payments are simulated in this demo. No real money moves.</div>
        {msg && <div className="text-sm text-red-300">{msg}</div>}<button className="btn w-full" disabled={busy} onClick={place}>{user ? 'Place order and pay' : 'Sign in to order'}</button></>}</aside></div></div>;
}

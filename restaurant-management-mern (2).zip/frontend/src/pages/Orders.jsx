import { useEffect } from 'react'; import api, { errMsg, money, socket } from '../services/api'; import { Async, Badge, Page, Table, statusTone, useFetch } from '../components/ui';
const NEXT = { Received: 'Confirmed', Confirmed: 'Preparing', Preparing: 'Ready', Ready: 'Completed', 'Out for Delivery': 'Completed', Served: 'Completed' };
export default function Orders() {
  const f = useFetch('/orders?limit=80'); useEffect(() => { socket.on('order:new', f.reload); socket.on('order:update', f.reload); return () => { socket.off('order:new', f.reload); socket.off('order:update', f.reload); }; }, []);
  const go = async (o, status) => { try { await api.patch(`/orders/${o._id}/status`, { status }); } catch (e) { alert(errMsg(e)); } };
  return <Page title="Orders" sub="Every channel: online, QR and POS. Updates live."><Async f={f}>{d => <Table rows={d} cols={[
    { h: 'Order', r: o => <b>{o.number}</b> }, { h: 'Customer', r: o => o.customerName }, { h: 'Type', r: o => `${o.type}${o.table ? ` · T${o.table.number}` : ''}` },
    { h: 'Items', r: o => o.items.map(i => `${i.qty}× ${i.name}`).join(', ') }, { h: 'Total', r: o => money(o.total) }, { h: 'Payment', r: o => <Badge tone={o.paymentStatus === 'Paid' ? 'ok' : 'medium'}>{o.paymentStatus}</Badge> },
    { h: 'Status', r: o => <Badge tone={statusTone(o.status)}>{o.status}</Badge> },
    { h: 'Action', r: o => <div className="flex gap-1">{NEXT[o.status] && <button className="btn px-2 py-1 text-xs" onClick={() => go(o, NEXT[o.status])}>{NEXT[o.status]}</button>}{['Received', 'Confirmed'].includes(o.status) && <button className="btn-ghost px-2 py-1 text-xs" onClick={() => go(o, 'Cancelled')}>Cancel</button>}</div> }]} />}</Async></Page>;
}

import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'; import { Link } from 'react-router-dom';
import { Async, Page, Stat, useFetch } from '../components/ui'; import { money } from '../services/api';
export default function Overview() {
  const o = useFetch('/analytics/overview'), s = useFetch('/analytics/sales?days=14');
  return <Page title="Overview" sub="Live view across your branch scope"><Async f={o}>{d => <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
    <Stat label="Revenue today" value={money(d.todayRevenue)} hint={`${d.todayOrders} orders`} /><Stat label="Active orders" value={d.activeOrders} tone="text-aqua" />
    <Link to="/app/exceptions"><Stat label="Open exceptions" value={d.openExceptions} tone={d.openExceptions ? 'text-orange-300' : 'text-emerald-300'} hint="Click to review" /></Link>
    <Link to="/app/inventory"><Stat label="Low-stock items" value={d.lowStock} tone={d.lowStock ? 'text-orange-300' : 'text-emerald-300'} /></Link>
    <Stat label="Total revenue" value={money(d.totalRevenue)} /><Stat label="Total orders" value={d.totalOrders} /><Stat label="Waste cost" value={money(d.wasteCost)} /></div>}</Async>
    <Async f={s}>{d => <div className="card"><div className="mb-3 font-bold">Revenue, last 14 days</div><div className="h-72"><ResponsiveContainer><AreaChart data={d}><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#22d3ee" stopOpacity=".5" /><stop offset="100%" stopColor="#22d3ee" stopOpacity="0" /></linearGradient></defs>
      <CartesianGrid stroke="#1b2c52" /><XAxis dataKey="date" stroke="#7b8bb0" tickFormatter={x => x.slice(5)} /><YAxis stroke="#7b8bb0" /><Tooltip contentStyle={{ background: '#0e1a36', border: '1px solid #1b2c52' }} /><Area dataKey="revenue" stroke="#22d3ee" fill="url(#g)" /></AreaChart></ResponsiveContainer></div></div>}</Async></Page>;
}

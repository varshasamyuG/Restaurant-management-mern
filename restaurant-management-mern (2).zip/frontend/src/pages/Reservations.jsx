import { useEffect, useState } from 'react'; import api, { errMsg } from '../services/api'; import { useAuth } from '../context/AuthContext'; import { Async, Badge, Page, Table, useFetch } from '../components/ui';
export default function Reservations() {
  const { user } = useAuth(), date = new Date().toISOString().slice(0, 10), r = useFetch('/reservations'), [branch, setBranch] = useState(user.branch || ''), [tables, setTables] = useState([]), [qr, setQr] = useState(null);
  useEffect(() => { api.get('/branches').then(x => { if (!branch) setBranch(x.data[0]._id); }); }, []);
  useEffect(() => { if (branch) api.get('/tables', { params: { branch } }).then(x => setTables(x.data)); }, [branch]);
  const set = async (x, status) => { try { await api.patch(`/reservations/${x._id}`, { status }); r.reload(); } catch (e) { alert(errMsg(e)); } };
  const showQr = async t => setQr({ t, ...(await api.get(`/tables/${t._id}/qr`)).data });
  const booked = id => (r.data || []).some(x => x.date === date && String(x.table?._id) === String(id) && x.status !== 'Cancelled');
  return <Page title="Tables & reservations" sub="Overlapping bookings for the same table are rejected."><div className="card"><div className="mb-3 font-bold">Floor plan (today)</div>
    <div className="grid grid-cols-4 gap-3 md:grid-cols-8">{tables.map(t => <button key={t._id} onClick={() => showQr(t)} className={`rounded-xl border p-3 text-center ${booked(t._id) ? 'border-orange-400 bg-orange-500/10' : 'border-emerald-400/50 bg-emerald-500/10'}`}><div className="font-bold">T{t.number}</div><div className="text-xs text-slate-400">{t.seats} seats</div></button>)}</div>
    {qr && <div className="mt-4 flex items-center gap-4"><img src={qr.qr} alt="Table QR" className="h-32 w-32 rounded bg-white p-1" /><div className="text-sm"><b>Table {qr.t.number} QR</b><div className="break-all text-slate-400">{qr.url}</div></div></div>}</div>
    <Async f={r}>{d => <Table rows={d} cols={[{ h: 'Date', r: x => `${x.date} ${x.time}` }, { h: 'Guest', r: x => x.name }, { h: 'Table', r: x => `T${x.table?.number}` }, { h: 'Guests', r: x => x.guests }, { h: 'Status', r: x => <Badge tone={x.status === 'Confirmed' ? 'ok' : x.status === 'Cancelled' ? 'critical' : 'medium'}>{x.status}</Badge> },
      { h: '', r: x => <div className="flex gap-1"><button className="btn px-2 py-1 text-xs" onClick={() => set(x, 'Confirmed')}>Confirm</button><button className="btn-ghost px-2 py-1 text-xs" onClick={() => set(x, 'Seated')}>Seated</button><button className="btn-ghost px-2 py-1 text-xs" onClick={() => set(x, 'Cancelled')}>Cancel</button></div> }]} />}</Async></Page>;
}

import {useEffect,useState,useCallback} from 'react';import {io} from 'socket.io-client';
import {LayoutDashboard,ClipboardList,ChefHat,Boxes,Truck,Brain,LogOut} from 'lucide-react';
import {ResponsiveContainer,AreaChart,Area,XAxis,YAxis,Tooltip,BarChart,Bar} from 'recharts';
import api,{err} from '../api.js';import {useAuth} from '../App.jsx';import Intelligence from './Intelligence.jsx';
const NAV={overview:[LayoutDashboard,'Overview',['admin','manager']],orders:[ClipboardList,'Orders',['admin','manager']],kitchen:[ChefHat,'Kitchen',['admin','manager','kitchen']],inventory:[Boxes,'Inventory',['admin','manager']],delivery:[Truck,'Delivery',['admin','manager','delivery']],intel:[Brain,'Smart Intelligence',['admin','manager']]};
const NEXT={Received:'Confirmed',Confirmed:'Preparing',Preparing:'Ready',Ready:'Served','Out for Delivery':'Completed',Served:'Completed'};
const mins=d=>Math.max(0,Math.floor((Date.now()-new Date(d))/6e4));
function useLive(path,deps=[]){const [d,setD]=useState([]);const load=useCallback(()=>api.get(path).then(r=>setD(r.data)).catch(()=>{}),[path,...deps]);
 useEffect(()=>{load();const s=io();s.on('order:update',load);const t=setInterval(load,30000);return()=>{s.close();clearInterval(t)}},[load]);return [d,load]}
const move=async(o,status,reload)=>{try{await api.patch(`/orders/${o._id}/status`,{status});reload()}catch(e){alert(err(e))}};

function Overview({branch}){const [d,setD]=useState(),[b,setB]=useState([]);useEffect(()=>{api.get('/analytics/overview',{params:{branch}}).then(r=>setD(r.data));api.get('/analytics/branches').then(r=>setB(r.data)).catch(()=>{})},[branch]);if(!d)return null;
 const C=[['Orders today',d.todayOrders],['Revenue today','₹'+d.todayRevenue],['Active orders',d.active],['Open exceptions',d.openExceptions],['Low-stock items',d.lowStock]];
 return <div className="space-y-5"><div className="grid grid-cols-2 gap-3 lg:grid-cols-5">{C.map(([l,v])=><div key={l} className="card"><p className="text-xs text-slate-400">{l}</p><p className="mt-1 text-2xl font-extrabold">{v}</p></div>)}</div>
  <div className="card"><h3 className="mb-3 font-bold">Revenue, last 14 days</h3><ResponsiveContainer width="100%" height={240}><AreaChart data={d.sales}><XAxis dataKey="date" tick={{fill:'#94a3b8',fontSize:11}} tickFormatter={x=>x.slice(5)}/><YAxis tick={{fill:'#94a3b8',fontSize:11}}/><Tooltip contentStyle={{background:'#0a1530',border:'1px solid #1e3a8a'}}/><Area dataKey="revenue" stroke="#22d3ee" fill="#2f6bff" fillOpacity={.35}/></AreaChart></ResponsiveContainer></div>
  {!!b.length&&<div className="card"><h3 className="mb-3 font-bold">Branch comparison (revenue)</h3><ResponsiveContainer width="100%" height={200}><BarChart data={b}><XAxis dataKey="branch" tick={{fill:'#94a3b8',fontSize:11}}/><YAxis tick={{fill:'#94a3b8',fontSize:11}}/><Tooltip contentStyle={{background:'#0a1530'}}/><Bar dataKey="revenue" fill="#2f6bff" radius={[6,6,0,0]}/></BarChart></ResponsiveContainer></div>}</div>}

function Orders(){const [o,load]=useLive('/orders');return <div className="card overflow-x-auto"><table className="w-full text-sm"><thead><tr><th>#</th><th>Type</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead><tbody>
 {o.slice(0,60).map(x=><tr key={x._id}><td>{x.number}</td><td>{x.type}{x.table&&` (${x.table})`}</td><td className="max-w-xs truncate">{x.items.map(i=>`${i.qty}× ${i.name}`).join(', ')}</td><td>₹{x.total}</td><td>{x.paymentStatus}</td><td>{x.status}</td>
 <td>{NEXT[x.status]&&(x.status!=='Ready'||x.type!=='delivery')&&<button className="btn" onClick={()=>move(x,NEXT[x.status],load)}>→ {NEXT[x.status]}</button>}</td></tr>)}</tbody></table></div>}

function Kitchen(){const [o,load]=useLive('/kitchen/orders');const [,tick]=useState(0);useEffect(()=>{const t=setInterval(()=>tick(x=>x+1),15000);return()=>clearInterval(t)},[]);
 const LIM={Received:10,Confirmed:10,Preparing:20,Ready:10};
 return <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{!o.length&&<p className="text-slate-400">No pending orders. New orders appear here live.</p>}{o.map(x=>{const m=mins(x.stamps?.[x.status]||x.createdAt),late=m>LIM[x.status];
  return <div key={x._id} className={`card ${late?'border-red-500/70':''}`}><div className="flex justify-between text-lg font-extrabold"><span>#{x.number}</span><span className={late?'text-red-400':'text-aqua'}>{m} min</span></div>
  <p className="text-xs text-slate-400">{x.type}{x.table&&` · ${x.table}`} · {x.status}{late&&' · DELAYED'}</p>
  <ul className="mt-3 space-y-1 text-lg">{x.items.map((i,k)=><li key={k}>{i.qty}× {i.name}{i.notes&&<span className="block text-sm text-amber-300">Note: {i.notes}</span>}</li>)}</ul>
  {NEXT[x.status]&&x.status!=='Ready'&&<button className="btn mt-4 w-full py-2.5 text-base" onClick={()=>move(x,NEXT[x.status],load)}>Mark {NEXT[x.status]}</button>}{x.status==='Ready'&&<p className="mt-4 rounded-lg bg-emerald-500/20 p-2 text-center text-emerald-300">Ready for pickup</p>}</div>})}</div>}

function Inventory(){const [i,load]=useLive('/inventory');return <div className="card overflow-x-auto"><table className="w-full text-sm"><thead><tr><th>Ingredient</th><th>Stock</th><th>Minimum</th><th>Status</th><th></th></tr></thead><tbody>
 {i.map(x=>{const low=x.stock<=x.minStock;return <tr key={x._id}><td>{x.name}</td><td>{x.stock} {x.unit}</td><td>{x.minStock}</td><td><span className={`badge ${low?'bg-red-500/20 text-red-300':'bg-emerald-500/20 text-emerald-300'}`}>{low?'Low stock':'OK'}</span></td>
 <td><button className="btn2" onClick={async()=>{await api.patch('/inventory/'+x._id,{add:20});load()}}>Stock in +20</button></td></tr>})}</tbody></table></div>}

function Delivery(){const [o,load]=useLive('/deliveries');return <div className="grid gap-4 sm:grid-cols-2">{!o.length&&<p className="text-slate-400">No delivery orders yet.</p>}{o.map(x=><div key={x._id} className="card"><div className="flex justify-between"><b>#{x.number}</b><span className="badge bg-volt/20 text-aqua">{x.status}</span></div>
 <p className="mt-1 text-sm text-slate-400">{x.address} · ₹{x.total} · {x.paymentStatus}</p>
 {x.status==='Ready'&&<button className="btn mt-3" onClick={async()=>{await api.patch(`/deliveries/${x._id}/status`,{status:'Out for Delivery'});load()}}>Accept and pick up</button>}
 {x.status==='Out for Delivery'&&<button className="btn mt-3" onClick={async()=>{await api.patch(`/deliveries/${x._id}/status`,{status:'Completed'});load()}}>Mark delivered</button>}</div>)}</div>}

export default function Staff(){const {user,logout}=useAuth();const items=Object.entries(NAV).filter(([,v])=>v[2].includes(user.role));const [p,setP]=useState(items[0][0]),[branches,setBr]=useState([]),[branch,setB]=useState('');
 useEffect(()=>{if(user.role==='admin')api.get('/branches').then(r=>setBr(r.data))},[]);
 const view={overview:<Overview branch={branch}/>,orders:<Orders/>,kitchen:<Kitchen/>,inventory:<Inventory/>,delivery:<Delivery/>,intel:<Intelligence branch={branch}/>}[p];
 return <div className="flex min-h-screen"><aside className="hidden w-56 shrink-0 border-r border-white/10 bg-navy-900/60 p-4 md:block"><h1 className="mb-6 font-extrabold text-aqua">RMS</h1>
  {items.map(([k,[Ic,l]])=><button key={k} onClick={()=>setP(k)} className={`mb-1 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm ${p===k?'bg-volt text-white':'text-slate-300 hover:bg-white/5'}`}><Ic size={16}/>{l}</button>)}</aside>
  <main className="flex-1 p-4 md:p-6"><div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><p className="text-xs text-slate-400">Dashboard / {user.role}</p><h2 className="text-xl font-extrabold">{NAV[p][1]}</h2></div>
   <div className="flex items-center gap-2"><div className="flex gap-1 md:hidden">{items.map(([k,[,l]])=><button key={k} className={p===k?'btn':'btn2'} onClick={()=>setP(k)}>{l}</button>)}</div>
    {user.role==='admin'&&<select className="inp w-auto" value={branch} onChange={e=>setB(e.target.value)}><option value="">All branches</option>{branches.map(b=><option key={b._id} value={b._id}>{b.name}</option>)}</select>}
    <span className="text-sm text-slate-400">{user.name}</span><button className="btn2" onClick={logout}><LogOut size={16}/></button></div></div>{view}</main></div>}

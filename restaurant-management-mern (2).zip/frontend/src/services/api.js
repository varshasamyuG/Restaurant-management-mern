import axios from 'axios'; import { io } from 'socket.io-client';
const base = import.meta.env.VITE_API_URL || 'http://localhost:5000';
const api = axios.create({ baseURL: `${base}/api` });
api.interceptors.request.use(c => { const t = localStorage.getItem('rms_token'); if (t) c.headers.Authorization = `Bearer ${t}`; return c; });
export const errMsg = e => e?.response?.data?.message || e.message;
export const socket = io(base, { autoConnect: true });
export const money = n => `₹${Math.round(n || 0).toLocaleString('en-IN')}`;
export default api;
